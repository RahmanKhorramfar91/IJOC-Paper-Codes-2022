#include <ilcplex/ilocplex.h>;
#include "ProblemData.h";
using namespace std;

typedef IloArray<IloNumVarArray> NumVar2D; // to define 2-D decision variables
typedef IloArray<NumVar2D> NumVar3D;  // to define 3-D decision variables
typedef IloArray<NumVar3D> NumVar4D;  // to define 4-D decision variables



void Print_on_File2(RandGen RG, int iter, double cpu_time, double corp, double eng,
	double sp2, double gap, double** X, double** Z, double** Y, bool IsFeasible, double& status, double MFG_obj)
{

#pragma region  Fetch Data
	int N = ProblemData::N;
	int T = ProblemData::T;

	int nP = ProblemData::nP;
	double** D = ProblemData::D;
	double* W = ProblemData::W;
	int* DD = ProblemData::DD;
	double** H = ProblemData::H;
	double* pi = ProblemData::pi;

	double b = ProblemData::b; // backorder cost
	double h = ProblemData::h; // holding cost
	double r = ProblemData::r; // production cost
	double* C = ProblemData::C; // total manufacturing capacity
	double tolerance = ProblemData::eps;
	double BigM = 10e11;
#pragma endregion

	ofstream fid;
	//string name = "ER2W (" + std::to_string(T) + "_" + std::to_string(N) + "_" + to_string(nP) + "_" + to_string(RG.seed) + ") .txt";

	fid.open("Bilevel(ENG_MFG)-MFG_Leader.txt", std::ios::app);
	fid << T << "-" << N << "-" << nP << "-" << RG.seed << "-";
	//fid << "\n\n" << endl;
	if (!IsFeasible)
	{
		fid << " not Feasible" << endl;
		fid.close();
		return;
	}
	/*else if ((IsFeasible && status == -2))
	{
		fid << "Couldn't solve the LB problem in the given time!" << endl;
		fid.close();
		return;
	}*/


	fid << "Iter:" << iter;
	fid << "\t CPU (sec): " << cpu_time / 1000;
	fid << "\t CORP Obj: " << corp;
	fid << "\t MFG Obj: " << MFG_obj;
	fid << "\t ENG Obj: " << eng;
	fid << "\t SP2 Obj: " << sp2;
	fid << "\t MIP Gap: " << gap;
	if (status == -2)
	{
		fid << "\t LB: No" << endl;
	}
	else
	{
		fid << "\t LB: Yes" << endl;
	}
	//fid << "\n" << endl;
	//double* UsedCap = new double[T]();
	//for (int t = 0; t < T; t++)
	//{
	//	//double Ct = 0;
	//	for (int n = 0; n < N; n++) {
	//		//if (X[n][t] != 0) { fid << " \t X[" << n << "][" << t << "] = " << X[n][t] << endl; }
	//		UsedCap[t] += X[n][t];
	//	}
	//	fid << " \t C[" << t << "] = " << UsedCap[t] << endl;
	//}
	/*fid << "\n" << endl;
	for (int n = 0; n < nP; n++)
	{
		for (int t = 0; t < T; t++) {
			if (Z[n][t] > 0.5) { fid << " \t Z[" << n << "][" << t << "] = " << Z[n][t] << endl; }
		}
	}
	for (int n = 0; n < nP; n++)
	{
		for (int t = 0; t < T; t++) {
			if (Y[n][t] > 0.5) { fid << " \t Y[" << n << "][" << t << "] = " << Y[n][t] << endl; }
		}
	}
	fid << "\n\n" << endl;
	for (int n = 0; n < N; n++)
	{
		for (int t = 0; t < T; t++) {
			if (X[n][t] != 0) { fid << " \t X[" << n << "][" << t << "] = " << X[n][t] << endl; }
		}
	}*/
	fid.close();
}


