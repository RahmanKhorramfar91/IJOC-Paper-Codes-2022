
#include "ProblemData.h";
#include "Funcs.h";

/* Code summary
Statrt date: 06/11/2019   end date: 3/29/2020
This code used the method proposed in the following paper to solve the bilevel
program of the semiconductor problem:
Rahman Khorramfar, Osman Ozaltin ...
*/
/*
HOW TO SET UP CPLEX FOR C++  :
https://bzdww.com/article/134619/
https://www.youtube.com/watch?v=Hbn1pGWLeaA
1) go to IBM directory in the program files in driver C
2) Go to concert folder -> include and when you see the "ilconcert" folder, copy the directory somewhere
3) Goto cplex folder -> include and when you see the "ilcplex" folder, copy the directory somewhere
4) In the solution Explorer tab, click on the project name and select properties
5) Go to C/C++ general ->" additional include directories" -> paste the two directories:
C:\Program Files\IBM\ILOG\CPLEX_Studio129\concert\include
C:\Program Files\IBM\ILOG\CPLEX_Studio129\cplex\include

6) Go to C/C++ general ->"Preprocessors" and add these words:
WIN32
_CONSOLE
IL_STD
_CRT_SECURE_NO_WARNINGS


Or
NDEBUG
_CONSOLE
IL_STD


7)  In the Project1 property page, select: "c/c++" - "code generation" - "runtime library",
set to "multithreaded DLL (/MD)". determine.

8) In the Project1 property page, select: "Linker" - "Input" - "Additional Dependencies",
and then enter the path of the following three files:
C:\Program Files\IBM\ILOG\CPLEX_Studio129\cplex\lib\x64_windows_vs2017\stat_mda\cplex1290.lib
C:\Program Files\IBM\ILOG\CPLEX_Studio129\cplex\lib\x64_windows_vs2017\stat_mda\ilocplex.lib
C:\Program Files\IBM\ILOG\CPLEX_Studio129\concert\lib\x64_windows_vs2017\stat_mda\concert.lib


9) if you're using visual studio 2017 with cplex 12.8, you may encounter an error which you then may
follow this link: https://www-01.ibm.com/support/docview.wss?uid=ibm10718671

*/

using namespace std;
int main(int argc, char* argv[]) {
	RandGen RG;
#pragma region Create default params
	std::default_random_engine gen(15964);
	int T3 = 18; int N3 = 14; int nP3 = 4;
	RG.Gen = gen;
	double* C3;// = new double[ProblemData::T];
	double* W3;// = new double[ProblemData::nP]();
	int* DD3;// = new int[ProblemData::nP]();
	double** H3;// = new double* [ProblemData::nP]();
	double* pi3;// = new double[ProblemData::N]();
	double** D3;// = new double* [ProblemData::N]();
	W3 = new double[nP3]; DD3 = new int[nP3]; H3 = new double* [nP3];
	C3 = new double[T3]; pi3 = new double[N3]; D3 = new double* [N3];
	int Old60 = (T3 * 0.6);
	int new60 = (T3 * 0.6);
	for (int p = 0; p < nP3; p++) { W3[p] = RG.randint(5, 100); }
	// Due date randint[0-5]
	for (int p = 0; p < nP3; p++) { DD3[p] = RG.randint(T3 - Old60 + 1, T3 - 2); }
	for (int n = 0; n < N3; n++) { pi3[n] = RG.randint(25, 30); }


	int Olddec = std::floor(Old60 / 4);  // in the last one-fourth of periods where old products produced, there will be diminish in the production
	int NewInc = std::floor(new60 / 4);

	// interval for demands
	vector<int*> Intervals;
	Intervals.push_back(new int[2]{ 600,1000 });
	Intervals.push_back(new int[2]{ 800,1200 });
	Intervals.push_back(new int[2]{ 1200,1600 });
	Intervals.push_back(new int[2]{ 1400,1800 });
	int nIntervals = Intervals.size();
	// populate demand for old products
	for (int n = nP3; n < N3; n++)
	{
		D3[n] = new double[T3]();
		int num1 = rand() % nIntervals; // choose an interval to generate from
		for (int t = 0; t < Old60 - Olddec; t++)
		{
			D3[n][t] = RG.randint(Intervals[num1][0], Intervals[num1][1]);
			//cout << D[n][t] << endl;
		}

		double dec = (Intervals[num1][0] / Olddec) + 10.0;
		int c1 = 0;
		for (int t = Old60 - Olddec; t < Old60; t++)
		{
			c1++;
			double num2 = RG.randint(Intervals[num1][0], Intervals[num1][1]);
			D3[n][t] = num2 - c1 * dec;
		}
	}
	// populate demand for new products
	for (int n = 0; n < nP3; n++)
	{
		D3[n] = new double[T3]();
		int num1 = rand() % nIntervals; // choose an interval to generate from
		for (int t = T3 - 1; t >= T3 - new60 + NewInc; t--)
		{
			D3[n][t] = RG.randint(Intervals[num1][0], Intervals[num1][1]);
		}

		double dec = (Intervals[num1][0] / NewInc) + 10.0;
		int c1 = 0;
		for (int t = T3 - new60 + NewInc - 1; t >= T3 - new60; t--)
		{
			c1++;
			double num2 = RG.randint(Intervals[num1][0], Intervals[num1][1]);
			D3[n][t] = num2 - c1 * dec;
		}
	}

	for (int t = 0; t < T3; t++)
	{
		double num1 = 0;
		for (int n = 0; n < N3; n++)
		{
			num1 += D3[n][t];
		}
		C3[t] = (int)(num1 * RG.unifrnd(0.7, 1.2));
	}

	// Fraction of factory resource required to develope product p unifrnd[0.2,0.6]
	for (int p = 0; p < nP3; p++)
	{
		H3[p] = new double[T3]();
		for (int t = 0; t < T3; t++)
		{
			double lbh = std::round(0.2 * C3[t]);
			double ubh = std::round(0.6 * C3[t]);
			H3[p][t] = RG.randint(lbh, ubh);
		}
	}

	RG.~RandGen();
#pragma endregion


	RandGen RG2;
	if (argc > 1)
	{
		ProblemData::T = atoi(argv[1]);
		ProblemData::N = atoi(argv[2]);
		ProblemData::nP = atoi(argv[3]);
		RG2.seed = atoi(argv[4]);
	}
	else
	{
		ProblemData::T = 18;
		ProblemData::N = 14;
		ProblemData::nP = 8;
		RG2.seed = 4;//4,163,506,731,999,1203
	}
	ProblemData::eps = (double)ProblemData::T * 10;
	//ProblemData::eps = 0;
	std::default_random_engine gen2(RG2.seed);
	RG2.Gen = gen2;
	ProblemData::RandomInstanceGenerator(RG2);
#pragma region Replace data with template
	for (int p = 0; p < nP3; p++)
	{
		for (int t = 0; t < T3; t++)
		{
			ProblemData::D[p][t] = D3[p][t];
			//ProblemData::H[p][t] = H3[p][t];			
		}
		ProblemData::W[p] = W3[p];
		ProblemData::DD[p] = DD3[p];
		ProblemData::pi[p] = pi3[p];
	}
	int cur_dem = 0;
	for (int p = ProblemData::nP; p < ProblemData::N; p++)
	{
		for (int t = 0; t < T3; t++)
		{
			ProblemData::D[p][t] = D3[nP3 + cur_dem][t];
		}
		ProblemData::pi[p] = pi3[p];
		cur_dem++;
	}

	for (int t = 0; t < T3; t++)
	{
		double num1 = 0;
		for (int n = 0; n < ProblemData::N; n++)
		{
			num1 += ProblemData::D[n][t];
		}
		ProblemData::C[t] = (int)(num1 * RG.unifrnd(0.7, 1.2));
	}

	// Fraction of factory resource required to develope product p unifrnd[0.2,0.6]
	for (int p = 0; p < ProblemData::nP; p++)
	{
		ProblemData::H[p] = new double[ProblemData::T]();
		for (int t = 0; t < ProblemData::T; t++)
		{
			double lbh = std::round(0.2 * ProblemData::C[t]);
			double ubh = std::round(0.6 * ProblemData::C[t]);
			ProblemData::H[p][t] = RG.randint(lbh, ubh);
		}
	}

#pragma endregion



#pragma region  Fetch Data
	int N = ProblemData::N;
	int T = ProblemData::T;

	int nP = ProblemData::nP;
	double** D = ProblemData::D;
	double* W = ProblemData::W;
	int* DD = ProblemData::DD;
	double** H = ProblemData::H;
	double* pi = ProblemData::pi;

	double b = ProblemData::b; // backorder cost
	double h = ProblemData::h; // holding cost
	double r = ProblemData::r; // production cost
	double* C = ProblemData::C; // total manufacturing capacity
#pragma endregion	




#pragma region Problem Parameters and Initial Values
	auto start = chrono::high_resolution_clock::now();

	double LB = 0;
	double UB = 10e12;  // upper bound
	double epsilon = 10e-4; // tolerance
	vector<EngSol> ZV;

	double** Zl = new double* [nP];
	double** Yl = new double* [nP];
	double** Zs = new double* [nP];
	double* Vs = new double[nP]();
	double** Ys = new double* [nP];
	double** Xs = new double* [N];
	double gap = -INFINITY;
	double EF_time = 3600;
	int ite = 0;
#pragma endregion

	double status = 1;
	bool IsFeasible = GetFeasibleSol(LB, Zl, Yl, status);
	if (!IsFeasible)
	{
		Print_on_File2(RG2, ite, 0, UB, 0, 0, gap, Xs, Zl, Yl, IsFeasible, status);
		return 0;
	}


	while (true)
	{
		ite++; gap = INFINITY;
		double corp_obj = RMP_Solution_Engine(ZV, Xs, Zs, Ys, Zl, Yl, gap, EF_time, LB, status);
		double RMP_eng = RMP_ENG_Obj(Zs);


		double ENGobj = -INFINITY;
		double SP2Obj = INFINITY;
		UB = INFINITY;
		if (gap < 0.001)
		{
			UB = corp_obj;
			Vs = new double[nP]();
			ENGobj = ENGSubProblem(Xs, Zs, Vs);

			if (RMP_eng <= ENGobj)
			{
				SP2Obj = RMP_eng;
			}
			else
			{
				SP2Obj = MFG_ENG_SP2(Xs);
			}
		}

		auto end = chrono::high_resolution_clock::now();
		auto Elapsed = chrono::duration_cast<chrono::milliseconds>(end - start);
		double duration = Elapsed.count();
		std::cout << "\n\n Iteration " << ite << "\t MP Obj: " << UB << "\t SP1 Obj: "
			<< ENGobj << "\t SP2 Obj: " << SP2Obj << endl;
		std::cout << "Time" << Elapsed.count() << endl;;
		std::cout << endl;

		if ((abs(SP2Obj - ENGobj) <= epsilon) || duration > 7.2e6 || std::abs(UB) == INFINITY)
		{
			// print the output
			Print_on_File2(RG2, ite, duration, UB, ENGobj, SP2Obj, gap, Xs, Zs, Ys, true, status);
			break;
		}
		else
		{
			//EngSol *newZV =  new EngSol(Zh, Vh);
			double** Znew = new double* [nP];
			double* Vnew = new double[nP];
			for (int p = 0; p < nP; p++)
			{
				Znew[p] = new double[T]();
				Vnew[p] = Vs[p];
				for (int t = 0; t < T; t++)
				{
					Znew[p][t] = Zs[p][t];
				}
			}
			EngSol newZV(Znew, Vnew);
			ZV.push_back(newZV);
			//ZV.push_back(EngSol());
			//ZV[ZV.size() - 1].Z = Zh;
			//ZV[ZV.size() - 1].V = Vh;
			//delete newZV;
		}

	}


}