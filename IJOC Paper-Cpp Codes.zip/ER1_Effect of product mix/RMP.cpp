#include <ilcplex/ilocplex.h>;
#include "ProblemData.h";
#include "Funcs.h";
using namespace std;
typedef IloArray<IloNumVarArray> NumVar2D; // to define 2-D decision variables
typedef IloArray<NumVar2D> NumVar3D;  // to define 3-D decision variables
typedef IloArray<NumVar3D> NumVar4D;  // to define 4-D decision variables\

struct Node
{
	int period;
	double obj;
	vector<int> DevP;
	vector<int> DevT;
};

// solve the MP for a while, 

double RMP_TimeLimit(vector<EngSol> ZV, double** Zl, double** Yl, double& gap,
	double LB, double EF_time, double** Xs, double** Zs, double** Ys, double status0)
{



#pragma region  Fetch Data
	int N = ProblemData::N;
	int T = ProblemData::T;

	int nP = ProblemData::nP;
	double** D = ProblemData::D;
	double* W = ProblemData::W;
	int* DD = ProblemData::DD;
	double** H = ProblemData::H;
	double* pi = ProblemData::pi;

	double b = ProblemData::b; // backorder cost
	double h = ProblemData::h; // holding cost
	double r = ProblemData::r; // production cost
	double* C = ProblemData::C; // total manufacturing capacity
	double tolerance = ProblemData::eps;
	//double BigM = 10e10;
	int Old60 = (T * 0.6); // old60 = new60
#pragma endregion	


	/*for (int j = 0; j < ZV.size(); j++)
	{
		for (int p = 0; p < nP; p++)
		{
			for (int t = 0; t < T; t++)
			{
				if (ZV[j].Z[p][t]>0.5)
				{
					cout << j << " " << p << " " << t << endl;
				}
			}
		}
	}
	cout << "ZL" << endl;
	for (int p = 0; p < nP; p++)
	{
		for (int t = 0; t < T; t++)
		{
			if (Zl[p][t] > 0.5)
			{
				cout<< p << " " << t << endl;
			}
		}
	}*/

#pragma region Define Original Variables
	IloEnv env;
	IloModel Model(env);

	IloNumVarArray V(env, nP, 0, IloInfinity, ILOFLOAT);
	NumVar2D B(env, N);
	NumVar2D X(env, N);
	NumVar2D Y(env, nP);
	NumVar2D Z(env, nP);
	NumVar2D I(env, N);


	for (int n = 0; n < N; n++)
	{
		B[n] = IloNumVarArray(env, T, 0, IloInfinity, ILOFLOAT);
		X[n] = IloNumVarArray(env, T, 0, 1, ILOFLOAT);
		I[n] = IloNumVarArray(env, T, 0, IloInfinity, ILOFLOAT);
	}

	for (int p = 0; p < nP; p++)
	{
		Z[p] = IloNumVarArray(env, T, 0, 1, ILOBOOL);
		Y[p] = IloNumVarArray(env, T, 0, 1, ILOBOOL);
	}
#pragma endregion

#pragma region Objective Function of the leader
	IloExpr ex0(env);
	for (int n = 0; n < N; n++)
	{
		for (int t = 0; t < T; t++)
		{
			if (t > 0)
			{
				ex0 += pi[n] * D[n][t];
				ex0 += pi[n] * B[n][t - 1];
				ex0 += -pi[n] * B[n][t];
			}
			else
			{
				ex0 += pi[n] * D[n][t];
				ex0 += -pi[n] * B[n][t];
			}
		}
	}

	Model.add(IloMaximize(env, ex0));
	Model.add(ex0 >= LB);
	ex0.end();
#pragma endregion

#pragma region Y_t =1 ==> Y_a>t =1
	for (int p = 0; p < nP; p++)
	{
		for (int t = 0; t < T - 1; t++)
		{
			Model.add(Y[p][t] <= Y[p][t + 1]);
		}
	}
#pragma endregion


#pragma region leader and followers Constraints 
	//MFG 0 define the Y variable
	for (int p = 0; p < nP; p++)
	{
		for (int t = 0; t < T; t++)
		{
			IloExpr ex0(env);
			for (int t2 = 0; t2 <= t; t2++)
			{
				ex0 += Z[p][t2];
			}
			//Model.add(1000 * Y[p][t] >= ex0);
			Model.add(Y[p][t] <= ex0);
			ex0.end();
		}
	}

	// MFG 1
	for (int n = 0; n < N; n++)
	{
		for (int t = 0; t < T; t++)
		{
			if (t > 0)
			{
				Model.add(I[n][t] == I[n][t - 1] + C[t] * X[n][t] - (D[n][t] + B[n][t - 1] - B[n][t]));
			}
			else
			{
				Model.add(I[n][t] == C[t] * X[n][t] - (D[n][t] - B[n][t]));
			}
		}
	}

	// MFG 2
	for (int t = 0; t < T; t++)
	{
		IloExpr ex4(env);
		for (int n = 0; n < N; n++)
		{
			ex4 += X[n][t];
		}
		Model.add(ex4 <= 1);
		ex4.end();
	}

	// MFG 3
	for (int p = 0; p < nP; p++)
	{
		for (int t = 0; t < T; t++)
		{
			Model.add(X[p][t] <= Y[p][t]);

		}
	}


	// Eng1 
	for (int p = 0; p < nP; p++)
	{
		for (int t = 0; t < T; t++)
		{
			IloExpr ex2(env);
			for (int t2 = 0; t2 < t; t2++)
			{
				ex2 += Z[p][t2];
			}
			Model.add(V[p] >= t * (1 - ex2) - DD[p]);
			ex2.end();
		}
	}

	// Eng2
	for (int t = 0; t < T; t++)
	{
		IloExpr ex7(env);
		for (int p = 0; p < nP; p++)
		{
			ex7 += H[p][t] * Z[p][t];
		}
		for (int n = 0; n < N; n++)
		{
			ex7 += C[t] * X[n][t];
		}
		Model.add(ex7 <= C[t]);
		ex7.end();
	}


	// Eng 3
	for (int p = 0; p < nP; p++)
	{
		IloExpr ex0(env);
		for (int t = 0; t < T; t++)
		{
			ex0 += Z[p][t];
		}
		Model.add(ex0 <= 1);
		ex0.end();
	}
#pragma endregion

#pragma region Define extra variables characterized by index j in J + MFG Dual variables
	int nJ = ZV.size();
	NumVar2D Vp(env, nJ);
	NumVar2D nu(env, nJ);

	for (int j = 0; j < nJ; j++) { nu[j] = IloNumVarArray(env, T, 0, 1, ILOBOOL); }

	// MFG Dual variables
	NumVar2D zeta(env, N);
	IloNumVarArray psi(env, T, -IloInfinity, 0, ILOFLOAT);
	NumVar2D theta(env, nP);
	for (int n = 0; n < N; n++)
	{
		zeta[n] = IloNumVarArray(env, T, -IloInfinity, IloInfinity, ILOFLOAT);
	}
	for (int p = 0; p < nP; p++)
	{
		theta[p] = IloNumVarArray(env, T, -IloInfinity, 0, ILOFLOAT);
		//for (int t = 0; t < T; t++)
		//{
		//	//string name = "theta[" + to_string(p) + "][" + to_string(t) + "]";
		//	//const char* name2 = name.c_str();
		//	theta[p][t] = IloNumVar(env, -IloInfinity, 0, ILOFLOAT, name2);
		//}
	}
#pragma endregion

#pragma region Generated Constraints for ENG model	
	NumVar2D gamma(env, nJ);

	for (int j = 0; j < nJ; j++) { gamma[j] = IloNumVarArray(env, T, 0, 1, ILOBOOL); }
	double M2 = 0;
	for (int p = 0; p < nP; p++)
	{
		M2 += W[p] * (T - DD[p]);
	}
	for (int j = 0; j < nJ; j++)
	{
		IloExpr eng(env);
		for (int p = 0; p < nP; p++)
		{
			eng += W[p] * V[p];
			eng -= W[p] * ZV[j].V[p];
		}
		for (int t = 0; t < T; t++)
		{
			eng -= M2 * gamma[j][t];
		}
		Model.add(eng <= 0);
		eng.end();
	}

	for (int j = 0; j < nJ; j++)
	{
		for (int t = 0; t < T; t++)
		{
			double Hbar = 0;
			for (int p = 0; p < nP; p++)
			{
				Hbar += H[p][t] * ZV[j].Z[p][t];
			}

			IloExpr eng1(env);
			for (int n = 0; n < N; n++)
			{
				eng1 += C[t] * X[n][t];
			}
			Model.add(Hbar * (1 - gamma[j][t]) <= C[t] - eng1);
			Model.add(Hbar - gamma[j][t] + C[t]*(1-gamma[j][t]) >= C[t] - eng1);
			//Model.add(IloIfThen(env, gamma[j][t] == 0, Hbar <= C[t] - eng1));		
			//Model.add(IloIfThen(env, gamma[j][t] == 1, Hbar - 1 >= C[t] - eng1));
			eng1.end();
		}
	}
#pragma endregion

#pragma region MFG Duals constraint
	// Dual MFG model
	for (int n = 0; n < N; n++)
	{
		for (int t = 0; t < T; t++)
		{
			if (t == T - 1)
			{
				Model.add(zeta[n][t] <= h);
			}
			else
			{
				Model.add(zeta[n][t] - zeta[n][t + 1] <= h);
			}
		}
	}

	for (int p = 0; p < nP; p++)
	{
		for (int t = 0; t < T; t++)
		{
			//for (int j = 0; j < nJ; j++)
			Model.add(-C[t] * zeta[p][t] + psi[t] + theta[p][t] <= r * C[t]);
		}
	}
	for (int n = nP; n < N; n++)
	{
		for (int t = 0; t < T; t++)
		{
			Model.add(-C[t] * zeta[n][t] + psi[t] <= r * C[t]);
		}
	}

	for (int n = 0; n < N; n++)
	{
		for (int t = 0; t < T; t++)
		{
			if (t == T - 1)
			{
				Model.add(-zeta[n][t] <= b);
			}
			else
			{
				Model.add(-zeta[n][t] + zeta[n][t + 1] <= b);
			}
		}
	}
#pragma endregion

#pragma region Linearize the non-linear term in the MFG-Dual objective function
	NumVar2D tY(env, nP);
	for (int p = 0; p < nP; p++)
	{
		tY[p] = IloNumVarArray(env, T, -IloInfinity, 0, ILOFLOAT);
	}
	double M3 = -10e8;
	for (int p = 0; p < nP; p++)
	{
		for (int t = 0; t < T; t++)
		{
			//Model.add(IloIfThen(env, Y[p][t] == 1, tY[p][t] == theta[p][t]));
			//Model.add(IloIfThen(env, Y[p][t] == 0, tY[p][t] == 0));
			Model.add(tY[p][t] >= M3 * Y[p][t]);
			Model.add(tY[p][t] >= theta[p][t]);
			Model.add(tY[p][t] <= theta[p][t] - M3 * (1 - Y[p][t]));
		}
	}
#pragma endregion

#pragma region Strong duality 
	IloExpr ex_MFG(env);
	for (int n = 0; n < N; n++)
	{
		for (int t = 0; t < T; t++)
		{

			ex_MFG += h * I[n][t];
			ex_MFG += r * C[t] * X[n][t];
			ex_MFG += b * B[n][t];

		}
	}

	IloExpr ex_MFG_Dual(env);
	for (int n = 0; n < N; n++)
	{
		if (n < nP)
		{
			for (int t = 0; t < T; t++)
			{
				ex_MFG_Dual += tY[n][t];
			}

		}
		for (int t = 0; t < T; t++)
		{
			ex_MFG_Dual += -zeta[n][t] * D[n][t];
		}
	}
	for (int t = 0; t < T; t++)
	{
		ex_MFG_Dual += psi[t];
	}

	Model.add(IloAbs(-ex_MFG_Dual + ex_MFG) <= tolerance);
	ex_MFG.end();
	ex_MFG_Dual.end();
#pragma endregion

	IloCplex cplex(Model);


#pragma region Warm Start
	IloNumVarArray XvarWarm(env);
	IloNumArray XvalWarm(env);
	IloNumVarArray YvarWarm(env);
	IloNumArray YvalWarm(env);
	if (status0 != -2)
	{
	for (int p = 0; p < nP; p++)
	{
		for (int t = 0; t < T; t++)
		{
			Model.add(Z[p][t]);
			Model.add(Y[p][t]);
			XvarWarm.add(Z[p][t]);
			XvalWarm.add(Zl[p][t]);
			YvarWarm.add(Y[p][t]);
			YvalWarm.add(Yl[p][t]);
		}
	}
	
		cplex.addMIPStart(XvarWarm, XvalWarm);
		cplex.addMIPStart(YvarWarm, YvalWarm);
	}

	XvarWarm.end(); XvalWarm.end(); YvarWarm.end(); YvalWarm.end();
#pragma endregion

#pragma region Solve the model
	cplex.setParam(IloCplex::TiLim, EF_time);
	//cplex.setParam(IloCplex::EpGap, 0.001);
	//cplex.exportModel("MA_LP.lp");
	//cplex.setOut(env.getNullStream());
	//cplex.setParam(IloCplex::Param::MIP::Strategy::Branch, 1); //Up/down branch selected first (1,-1),  default:automatic (0)
	//cplex.setParam(IloCplex::Param::MIP::Strategy::BBInterval, 7);// 0 to 7
	//cplex.setParam(IloCplex::Param::MIP::Strategy::NodeSelect, 2);//https://www.ibm.com/support/knowledgecenter/SSSA5P_12.9.0/ilog.odms.cplex.help/CPLEX/UsrMan/topics/discr_optim/mip/performance/20_node_seln.html
	//cplex.setParam(IloCplex::Param::MIP::Strategy::VariableSelect, 4);//-1 to 4
	//cplex.setParam(IloCplex::Param::RootAlgorithm, 4); /000 to 6
	if (!cplex.solve()) {
		Model.end();
		cplex.end();
		// set the feasible solution to the Zl,Yl		
		for (int n = 0; n < nP; n++)
		{
			Zs[n] = new double[T]();
			Ys[n] = new double[T]();
			for (int t = 0; t < T; t++)
			{

				Zs[n][t] = Zl[n][t];
				Ys[n][t] = Yl[n][t];
			}
		}
		return -1;
	}

	double obj = cplex.getObjValue();
	gap = cplex.getMIPRelativeGap();

	if (obj >= LB)
	{
		// get the value of X
		for (int n = 0; n < N; n++)
		{
			Xs[n] = new double[T]();
			for (int t = 0; t < T; t++)
			{
				Xs[n][t] = cplex.getValue(X[n][t]);
			}
		}
		// get Zs and Ys
		for (int n = 0; n < nP; n++)
		{
			Zs[n] = new double[T]();
			Ys[n] = new double[T]();
			for (int t = 0; t < T; t++)
			{
				Zs[n][t] = cplex.getValue(Z[n][t]);
				Ys[n][t] = cplex.getValue(Y[n][t]);
				/*if (Zs[n][t] > 0.5)
				{
					cout << n << "  " << t << endl;
				}*/
			}
		}
	}
#pragma endregion

	Model.end();
	cplex.end();

	return obj;
}


bool RMP_SomeVarsFixed(vector<EngSol> ZV, double** Xs, double** Zs, double** Ys,
	vector<int> DevP, vector<int> DevT, double& IncumSolObj, bool WSP)
{

#pragma region  Fetch Data
	int N = ProblemData::N;
	int T = ProblemData::T;

	int nP = ProblemData::nP;
	double** D = ProblemData::D;
	double* W = ProblemData::W;
	int* DD = ProblemData::DD;
	double** H = ProblemData::H;
	double* pi = ProblemData::pi;

	double b = ProblemData::b; // backorder cost
	double h = ProblemData::h; // holding cost
	double r = ProblemData::r; // production cost
	double* C = ProblemData::C; // total manufacturing capacity
	double tolerance = ProblemData::eps;
	//double BigM = 10e12;
	int Old60 = (T * 0.6); // old60 = new60
#pragma endregion	

#pragma region Define Original Variables
	IloEnv env;
	IloModel Model(env);

	IloNumVarArray V(env, nP, 0, IloInfinity, ILOFLOAT);
	NumVar2D B(env, N);
	NumVar2D X(env, N);
	NumVar2D Y(env, nP);
	NumVar2D Z(env, nP);
	NumVar2D I(env, N);


	for (int n = 0; n < N; n++)
	{
		B[n] = IloNumVarArray(env, T, 0, IloInfinity, ILOFLOAT);
		X[n] = IloNumVarArray(env, T, 0, 1, ILOFLOAT);
		I[n] = IloNumVarArray(env, T, 0, IloInfinity, ILOFLOAT);
	}

	for (int p = 0; p < nP; p++)
	{
		Z[p] = IloNumVarArray(env, T, 0, 1, ILOBOOL);
		Y[p] = IloNumVarArray(env, T, 0, 1, ILOBOOL);
	}
#pragma endregion

#pragma region Objective Function of the leader
	IloExpr ex0(env);
	for (int n = 0; n < N; n++)
	{
		for (int t = 0; t < T; t++)
		{
			if (t > 0)
			{
				ex0 += pi[n] * D[n][t];
				ex0 += pi[n] * B[n][t - 1];
				ex0 += -pi[n] * B[n][t];
			}
			else
			{
				ex0 += pi[n] * D[n][t];
				ex0 += -pi[n] * B[n][t];
			}
		}
	}

	Model.add(IloMaximize(env, ex0));
	Model.add(ex0 >= IncumSolObj);
	ex0.end();
#pragma endregion

#pragma region Y_t =1 ==> Y_a>t =1
	for (int p = 0; p < nP; p++)
	{
		for (int t = 0; t < T - 1; t++)
		{
			Model.add(Y[p][t] <= Y[p][t + 1]);
		}
	}
#pragma endregion

#pragma region leader and followers Constraints 
	//MFG 0 define the Y variable
	for (int p = 0; p < nP; p++)
	{
		for (int t = 0; t < T; t++)
		{
			IloExpr ex0(env);
			for (int t2 = 0; t2 <= t; t2++)
			{
				ex0 += Z[p][t2];
			}
			//Model.add(1000 * Y[p][t] >= ex0);
			Model.add(Y[p][t] <= ex0);
			ex0.end();
		}
	}

	// MFG 1
	for (int n = 0; n < N; n++)
	{
		for (int t = 0; t < T; t++)
		{
			if (t > 0)
			{
				Model.add(I[n][t] == I[n][t - 1] + C[t] * X[n][t] - (D[n][t] + B[n][t - 1] - B[n][t]));
			}
			else
			{
				Model.add(I[n][t] == C[t] * X[n][t] - (D[n][t] - B[n][t]));
			}
		}
	}

	// MFG 2
	for (int t = 0; t < T; t++)
	{
		IloExpr ex4(env);
		for (int n = 0; n < N; n++)
		{
			ex4 += X[n][t];
		}
		Model.add(ex4 <= 1);
		ex4.end();
	}

	// MFG 3
	for (int p = 0; p < nP; p++)
	{
		for (int t = 0; t < T; t++)
		{
			Model.add(X[p][t] <= Y[p][t]);

		}
	}


	// Eng1 
	for (int p = 0; p < nP; p++)
	{
		for (int t = 0; t < T; t++)
		{
			IloExpr ex2(env);
			for (int t2 = 0; t2 < t; t2++)
			{
				ex2 += Z[p][t2];
			}
			Model.add(V[p] >= t * (1 - ex2) - DD[p]);
			ex2.end();
		}
	}

	// Eng2
	for (int t = 0; t < T; t++)
	{
		IloExpr ex7(env);
		for (int p = 0; p < nP; p++)
		{
			ex7 += H[p][t] * Z[p][t];
		}
		for (int n = 0; n < N; n++)
		{
			ex7 += C[t] * X[n][t];
		}
		Model.add(ex7 <= C[t]);
		ex7.end();
	}


	// Eng 3
	for (int p = 0; p < nP; p++)
	{
		IloExpr ex0(env);
		for (int t = 0; t < T; t++)
		{
			ex0 += Z[p][t];
		}
		Model.add(ex0 <= 1);
		ex0.end();
	}
#pragma endregion

#pragma region Define extra variables characterized by index j in J + MFG Dual variables
	int nJ = ZV.size();
	NumVar2D Vp(env, nJ);
	NumVar2D nu(env, nJ);

	for (int j = 0; j < nJ; j++) { nu[j] = IloNumVarArray(env, T, 0, 1, ILOBOOL); }

	// MFG Dual variables
	NumVar2D zeta(env, N);
	IloNumVarArray psi(env, T, -IloInfinity, 0, ILOFLOAT);
	NumVar2D theta(env, nP);
	for (int n = 0; n < N; n++)
	{
		zeta[n] = IloNumVarArray(env, T, -IloInfinity, IloInfinity, ILOFLOAT);
	}
	for (int p = 0; p < nP; p++)
	{
		theta[p] = IloNumVarArray(env, T, -IloInfinity, 0, ILOFLOAT);
		//for (int t = 0; t < T; t++)
		//{
		//	//string name = "theta[" + to_string(p) + "][" + to_string(t) + "]";
		//	//const char* name2 = name.c_str();
		//	theta[p][t] = IloNumVar(env, -IloInfinity, 0, ILOFLOAT, name2);
		//}
	}
#pragma endregion

#pragma region Generated Constraints for ENG model	
	NumVar2D gamma(env, nJ);

	for (int j = 0; j < nJ; j++) { gamma[j] = IloNumVarArray(env, T, 0, 1, ILOBOOL); }
	double M2 = 0;
	for (int p = 0; p < nP; p++)
	{
		M2 += W[p] * (T - DD[p]);
	}
	for (int j = 0; j < nJ; j++)
	{
		IloExpr eng(env);
		for (int p = 0; p < nP; p++)
		{
			eng += W[p] * V[p];
			eng -= W[p] * ZV[j].V[p];
		}
		for (int t = 0; t < T; t++)
		{
			eng -= M2 * gamma[j][t];
		}
		Model.add(eng <= 0);
		eng.end();
	}

	for (int j = 0; j < nJ; j++)
	{
		for (int t = 0; t < T; t++)
		{
			double Hbar = 0;
			for (int p = 0; p < nP; p++)
			{
				Hbar += H[p][t] * ZV[j].Z[p][t];
			}

			IloExpr eng1(env);
			for (int n = 0; n < N; n++)
			{
				eng1 += C[t] * X[n][t];
			}
			Model.add(Hbar * (1 - gamma[j][t]) <= C[t] - eng1);
			Model.add(Hbar - gamma[j][t] + C[t] * (1 - gamma[j][t]) >= C[t] - eng1);
			//Model.add(IloIfThen(env, gamma[j][t] == 0, Hbar <= C[t] - eng1));		
			//Model.add(IloIfThen(env, gamma[j][t] == 1, Hbar - 1 >= C[t] - eng1));
			eng1.end();
		}
	}
#pragma endregion

#pragma region MFG Duals constraint
	// Dual MFG model
	for (int n = 0; n < N; n++)
	{
		for (int t = 0; t < T; t++)
		{
			if (t == T - 1)
			{
				Model.add(zeta[n][t] <= h);
			}
			else
			{
				Model.add(zeta[n][t] - zeta[n][t + 1] <= h);
			}
		}
	}

	for (int p = 0; p < nP; p++)
	{
		for (int t = 0; t < T; t++)
		{
			//for (int j = 0; j < nJ; j++)
			Model.add(-C[t] * zeta[p][t] + psi[t] + theta[p][t] <= r * C[t]);
		}
	}
	for (int n = nP; n < N; n++)
	{
		for (int t = 0; t < T; t++)
		{
			Model.add(-C[t] * zeta[n][t] + psi[t] <= r * C[t]);
		}
	}

	for (int n = 0; n < N; n++)
	{
		for (int t = 0; t < T; t++)
		{
			if (t == T - 1)
			{
				Model.add(-zeta[n][t] <= b);
			}
			else
			{
				Model.add(-zeta[n][t] + zeta[n][t + 1] <= b);
			}
		}
	}
#pragma endregion

#pragma region Linearize the non-linear term in the MFG-Dual objective function
	NumVar2D tY(env, nP);
	for (int p = 0; p < nP; p++)
	{
		tY[p] = IloNumVarArray(env, T, -IloInfinity, 0, ILOFLOAT);
	}
	double M3 = -10e8;
	for (int p = 0; p < nP; p++)
	{
		for (int t = 0; t < T; t++)
		{
			//Model.add(IloIfThen(env, Y[p][t] == 1, tY[p][t] == theta[p][t]));
			//Model.add(IloIfThen(env, Y[p][t] == 0, tY[p][t] == 0));
			Model.add(tY[p][t] >= M3 * Y[p][t]);
			Model.add(tY[p][t] >= theta[p][t]);
			Model.add(tY[p][t] <= theta[p][t] - M3 * (1 - Y[p][t]));
		}
	}
#pragma endregion


#pragma region Strong duality 
	IloExpr ex_MFG(env);
	for (int n = 0; n < N; n++)
	{
		for (int t = 0; t < T; t++)
		{

			ex_MFG += h * I[n][t];
			ex_MFG += r * C[t] * X[n][t];
			ex_MFG += b * B[n][t];

		}
	}

	IloExpr ex_MFG_Dual(env);
	for (int n = 0; n < N; n++)
	{
		if (n < nP)
		{
			for (int t = 0; t < T; t++)
			{
				ex_MFG_Dual += tY[n][t];
			}

		}
		for (int t = 0; t < T; t++)
		{
			ex_MFG_Dual += -zeta[n][t] * D[n][t];
		}
	}
	for (int t = 0; t < T; t++)
	{
		ex_MFG_Dual += psi[t];
	}

	Model.add(IloAbs(-ex_MFG_Dual + ex_MFG) <= tolerance);
	ex_MFG.end();
	ex_MFG_Dual.end();
#pragma endregion

#pragma region Fix variables
	for (int i = 0; i < DevP.size(); i++)
	{
		Model.add(Z[DevP[i]][DevT[i]] == 1);
	}
#pragma endregion

	IloCplex cplex(Model);

#pragma region Warm Start
	IloNumVarArray XvarWarm(env);
	IloNumArray XvalWarm(env);
	IloNumVarArray YvarWarm(env);
	IloNumArray YvalWarm(env);
	for (int p = 0; p < nP; p++)
	{
		for (int t = 0; t < T; t++)
		{
			Model.add(Z[p][t]);
			Model.add(Y[p][t]);
			XvarWarm.add(Z[p][t]);
			XvalWarm.add(Zs[p][t]);
			YvarWarm.add(Y[p][t]);
			YvalWarm.add(Ys[p][t]);
		}
	}
	if (WSP)
	{
		cplex.addMIPStart(XvarWarm, XvalWarm);
		cplex.addMIPStart(YvarWarm, YvalWarm);
	}

	XvarWarm.end(); XvalWarm.end(); YvarWarm.end(); YvalWarm.end();
#pragma endregion

#pragma region Solve the model

	cplex.setParam(IloCplex::TiLim, 60);
	//cplex.setParam(IloCplex::EpGap, 0.001);
	//cplex.exportModel("MA_LP.lp");
	//cplex.setOut(env.getNullStream());
	//cplex.setParam(IloCplex::Param::MIP::Strategy::Branch, 1); //Up/down branch selected first (1,-1),  default:automatic (0)
	//cplex.setParam(IloCplex::Param::MIP::Strategy::BBInterval, 7);// 0 to 7
	//cplex.setParam(IloCplex::Param::MIP::Strategy::NodeSelect, 2);//https://www.ibm.com/support/knowledgecenter/SSSA5P_12.9.0/ilog.odms.cplex.help/CPLEX/UsrMan/topics/discr_optim/mip/performance/20_node_seln.html
	//cplex.setParam(IloCplex::Param::MIP::Strategy::VariableSelect, 4);//-1 to 4
	//cplex.setParam(IloCplex::Param::RootAlgorithm, 4); // 0 to 6
	if (!cplex.solve()) {
		env.error() << "Failed to optimize the Master Problem!!!" << endl;
		return false;
	}

	double obj = cplex.getObjValue();
	//gap = cplex.getMIPRelativeGap();

	//if (obj > IncumSolObj) //update Xs, Zs, Ys, and IncumSolObj
	{
		IncumSolObj = obj;
		// get the value of X
		for (int n = 0; n < N; n++)
		{
			Xs[n] = new double[T]();
			for (int t = 0; t < T; t++)
			{
				Xs[n][t] = cplex.getValue(X[n][t]);
			}
		}
		// get Zs and Ys
		for (int n = 0; n < nP; n++)
		{
			Zs[n] = new double[T]();
			Ys[n] = new double[T]();
			for (int t = 0; t < T; t++)
			{
				Zs[n][t] = cplex.getValue(Z[n][t]);
				Ys[n][t] = cplex.getValue(Y[n][t]);
			}
		}
	}
#pragma endregion

	Model.end();
	cplex.end();

	return true;
}


vector<vector<int>> CreateChildren(vector<int> DevP, int time)
{

#pragma region  Fetch Data
	int N = ProblemData::N;
	int T = ProblemData::T;

	int nP = ProblemData::nP;
	double** D = ProblemData::D;
	double* W = ProblemData::W;
	int* DD = ProblemData::DD;
	double** H = ProblemData::H;
	double* pi = ProblemData::pi;

	double b = ProblemData::b; // backorder cost
	double h = ProblemData::h; // holding cost
	double r = ProblemData::r; // production cost
	double* C = ProblemData::C; // total manufacturing capacity
	double tolerance = ProblemData::eps;
	//double BigM = 10e7;
	int Old60 = (T * 0.6); // old60 = new60
#pragma endregion	

	vector<vector<int>> Sig;


	vector<int> prods(nP); // vector with nP elements 

	vector<int> remP;
	for (int p = 0; p < nP; p++)
	{
		if (std::count(DevP.begin(), DevP.end(), p)) { continue; }
		remP.push_back(p);
	}

	prods.clear();

#pragma region Solve the binary knapsack problem with a constant objective
	// use cplex SolnPool command to obtain all the feasible solutions
	//to the knapsack problem (sum_{p in P} H*Z <= rem)
	//http://home.engineering.iastate.edu/~jdm/ee458/CPLEX-UsersManual2015.pdf chapter 17

	IloEnv env;
	IloModel Model(env);
	int nItems = remP.size();
	IloNumVarArray z(env, nItems, 0, 1, ILOBOOL);
	int ConstantObj = 10;
	Model.add(IloMinimize(env, 10));

	IloExpr ex1(env);
	for (int p = 0; p < nItems; p++)
	{
		ex1 += z[p] * H[remP[p]][time];
	}
	Model.add(ex1 <= C[time]);
	ex1.end();


	if (time >= Old60)
	{
		Model.add(IloSum(z) >= 1);
	}
	bool fit2items = false;
	if (remP.size() >= 2)
	{
		for (int i = 0; i < remP.size(); i++)
		{
			for (int j = 0; j < remP.size(); j++)
			{
				if (H[remP[i]][time] + H[remP[j]][time] <= 1)
				{
					fit2items = true; break;
				}
			}
		}
		if (fit2items && time >= Old60 + 1)
		{
			Model.add(IloSum(z) >= 2);
		}
	}
	/*if (time >= Told60)
	{
		Model.add(IloSum(z) >= 1);
	}*/

	IloCplex cplex(Model);
#pragma endregion
	cplex.setParam(IloCplex::Param::MIP::Pool::Intensity, 4);
	cplex.setParam(IloCplex::Param::MIP::Pool::AbsGap, 0);
	cplex.setParam(IloCplex::Param::MIP::Pool::Capacity, 10000);

	cplex.setOut(env.getNullStream());
	cplex.solve();
	cplex.populate();
	int nPool = cplex.getSolnPoolNsolns();
	int solCount = 0;
	int nChild = 10;
	if (nP >= 10)
	{
		nChild = 10;
	}
	else
	{
		nChild = 20;
	}

	if (time == Old60)
	{
		nChild = nChild;
	}
	else
	{
		nChild = std::round(nChild / 2);
	}


	for (int s = 0; s < nPool; s++)
	{
		solCount++;
		prods.clear();
		for (int i = 0; i < nItems; i++)
		{
			double zis = cplex.getValue(z[i], s);
			if (zis > 0.5)
			{
				prods.push_back(remP[i]);
			}
		}
		Sig.push_back(prods);
		if (solCount >= nChild)
		{
			break;
		}
	}
	Model.end(); cplex.end();
	return Sig;

}


double RMP_Solution_Engine(vector<EngSol> ZV, double** Xs,
	double** Zs, double** Ys, double** Zl, double** Yl, double& gap,
	double EF_time, double LB, double status0)
{

#pragma region  Fetch Data
	int N = ProblemData::N;
	int T = ProblemData::T;

	int nP = ProblemData::nP;
	double** D = ProblemData::D;
	double* W = ProblemData::W;
	int* DD = ProblemData::DD;
	double** H = ProblemData::H;
	double* pi = ProblemData::pi;

	double b = ProblemData::b; // backorder cost
	double h = ProblemData::h; // holding cost
	double r = ProblemData::r; // production cost
	double* C = ProblemData::C; // total manufacturing capacity
	double tolerance = ProblemData::eps;
	//double BigM = 10e7;
	int Old60 = (T * 0.6); // old60 = new60
#pragma endregion	

	double Corp_obj0 = 0;
	Corp_obj0 = RMP_TimeLimit(ZV, Zl, Yl, gap, LB, 50, Xs, Zs, Ys, status0);
	if (gap < 0.001 && Corp_obj0 != -1) { return Corp_obj0; }
	double BB_LB = 0;
	bool WarmStartPossible = false;
	if (status0 != -2) { WarmStartPossible = true; }



	if (Corp_obj0 == -1) { BB_LB = LB; }
	else { BB_LB = Corp_obj0; WarmStartPossible = true; }


	// perform the BB to get a better lower bound
	// lower bound: a feasible solution to the RMP at the current iteration
#pragma region Branch and Bound Heuristics
	int InitTime = Old60;
	vector<Node> Nodes;
	Node node;
	node.obj = -1;
	node.period = InitTime - 1;
	Nodes.push_back(node);
	double IncumbentSolutionObj = BB_LB;
	int nNodesCreated = 1;
	bool fif = false;
	int Inum = 0;
	int FixCriteria = nP - 1;
	int nEval = 5;
	/*if (nP<10)
	{
		FixCriteria = nP - 1;
	}
	else
	{
		FixCriteria = nP;
	}*/
	int Evs = 0;
	while (Nodes.size() <= nP * 1000)
	{
		if (Nodes[0].period == T)
		{
			break;
		}
		if (Nodes[0].DevP.size() >= FixCriteria)
		{
			Evs++;
			bool IsBetter = RMP_SomeVarsFixed(ZV, Xs, Zs, Ys,
				Nodes[0].DevP, Nodes[0].DevT, IncumbentSolutionObj, WarmStartPossible);
			if (IsBetter || Evs >= nEval)
			{
				status0 = 1;
				break;
			}
			Nodes.erase(Nodes.begin()); continue;
		}

		Node ParentNode = Nodes[0];
		vector<vector<int>> Sigma = CreateChildren(ParentNode.DevP, ParentNode.period + 1);

		for (vector<int> devp : Sigma)
		{
			nNodesCreated++;
			Node NewNode = ParentNode;
			NewNode.DevP.insert(NewNode.DevP.end(), devp.begin(), devp.end());
			vector<int> newT(devp.size(), ParentNode.period + 1);
			NewNode.DevT.insert(NewNode.DevT.end(), newT.begin(), newT.end());
			NewNode.period = ParentNode.period + 1;

			Nodes.push_back(NewNode);
		}
		Nodes.erase(Nodes.begin());
	}
#pragma endregion




	Corp_obj0 = RMP_TimeLimit(ZV, Zs, Ys, gap, 0, 3600, Xs, Zs, Ys, status0);
	if (Corp_obj0 == -1)
	{
		return -1;
	}

	return Corp_obj0;
}



double RMP_ENG_Obj(double** z)
{

#pragma region  Fetch Data
	int T = ProblemData::T;
	int nP = ProblemData::nP;
	double* W = ProblemData::W;
	int* DD = ProblemData::DD;
#pragma endregion	

	int* V = new int[nP]();
	double RMP_ENG_obj_value = 0;


	//	Model.add(V[p] >= t * (1 - ex2) - DD[p]);


	for (int p = 0; p < nP; p++)
	{
		for (int t = 0; t < T; t++)
		{
			int Acummul = 0;
			for (int t2 = 0; t2 < t; t2++)
			{
				Acummul += z[p][t2];
			}
			V[p] = std::max(V[p], t * (1 - Acummul) - DD[p]);
		}
		RMP_ENG_obj_value += V[p] * W[p];
	}
	return RMP_ENG_obj_value;
}