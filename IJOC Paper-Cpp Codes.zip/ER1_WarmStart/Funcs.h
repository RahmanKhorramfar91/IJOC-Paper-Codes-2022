#pragma once
#include "ProblemData.h";
using namespace std;



double ENGSubProblem(double** Xh, double** Zh, double* Vh);
double MFG_ENG_SP2(double** Xs);

void MKP_Heuristic(int RecT, double CapCoef, double** Zl);
bool ENG_Leader_Feasible(double** Zs, double** Ys);
bool ENG_Leader_WarmStart_ZY(double** Zl, double** Yl, double& LB, double& status);
bool GetFeasibleSol(double& LB, double** Zs, double** Ys, double& status);


double RMP_TimeLimit(vector<EngSol> ZV, double** Zl, double** Yl, double& gap,
	double LB, double EF_time, double** Xs,
	double** Zs, double** Ys, double status);
bool RMP_SomeVarsFixed(vector<EngSol> ZV, double** Xs, double** Zs,
	double** Ys, vector<int> DevP, vector<int> DevT, double& IncumSolObj, bool WarmStartPossible);
vector<vector<int>> CreateChildren(vector<int> DevP, int time);
double RMP_Solution_Engine(vector<EngSol> ZV, double** Xs, double** Zs, double** Ys,
	double** Zl, double** Yl, double& gap, double EF_time, double LB, double status);
double RMP_ENG_Obj(double** z);




void Print_on_File(RandGen RG, int iter, double cpu_time, double corp, double eng,
	double sp2, double gap, double** X, double** Z, double** Y, bool IsFeasible, double& status);
double MFG(double** Xs);
void Print_on_File2(RandGen RG, int iter, double cpu_time, double corp, double eng,
	double sp2, double gap, double** X, double** Z, double** Y, bool IsFeasible, double& status);
double MFG(double** Xs);