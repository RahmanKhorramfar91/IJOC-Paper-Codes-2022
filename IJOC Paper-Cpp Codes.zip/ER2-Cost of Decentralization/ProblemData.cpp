#include "ProblemData.h"


int RandGen::randint(int a, int b) {
	std::uniform_int_distribution<int> randint(a, b);
	return randint(Gen);
}

double RandGen::unifrnd(double a, double b) {
	std::uniform_real_distribution<double> unifrnd(a, b);
	return unifrnd(Gen);
}


using namespace std;
//int ProblemData::seed;
//std::default_random_engine gen(ProblemData::seed);
//
//int randint(int a, int b) {
//	std::uniform_int_distribution<int> randint(a, b);
//	return randint(gen);
//}
//
//static double unifrnd(double a, double b) {
//	std::uniform_real_distribution<double> unifrnd(a, b);
//	return unifrnd(gen);
//}

#pragma region  feed data with parameter values
int ProblemData::T;  //T=10, N=6, nP = 3 
int ProblemData::N;  // T=10, N=8, nP=6, Iter=3;     
int ProblemData::nP;

double ProblemData::h = 0.5;

double ProblemData::eps;

double ProblemData::b;
double ProblemData::r;
double* ProblemData::C;// = new double[ProblemData::T];
double* ProblemData::W;// = new double[ProblemData::nP]();
int* ProblemData::DD;// = new int[ProblemData::nP]();
double** ProblemData::H;// = new double* [ProblemData::nP]();
double* ProblemData::pi;// = new double[ProblemData::N]();
double** ProblemData::D;// = new double* [ProblemData::N]();
#pragma endregion

void ProblemData::RandomInstanceGenerator(RandGen RG) {
	ProblemData::r = 2 * ProblemData::h;//10
	ProblemData::b = 10 * ProblemData::h;//20

	W = new double[nP]; DD = new int[nP]; H = new double* [nP];
	C = new double[T]; pi = new double[N]; D = new double* [N];

#pragma region not critical parameters
	// production development priority randint[5-10]
	int Old60 = (ProblemData::T * 0.6);
	int new60 = (ProblemData::T * 0.6);
	for (int p = 0; p < nP; p++) { W[p] = RG.randint(5, 100); }
	// Due date randint[0-5]
	for (int p = 0; p < nP; p++) { DD[p] = RG.randint(T - Old60 + 1, T - 2); }
	for (int n = 0; n < N; n++) { pi[n] = RG.randint(25, 30); }


	int Olddec = std::floor(Old60 / 4);  // in the last one-fourth of periods where old products produced, there will be diminish in the production
	int NewInc = std::floor(new60 / 4);

	// interval for demands
	vector<int*> Intervals;
	Intervals.push_back(new int[2]{ 600,1000 });
	Intervals.push_back(new int[2]{ 800,1200 });
	Intervals.push_back(new int[2]{ 1200,1600 });
	Intervals.push_back(new int[2]{ 1400,1800 });
	int nIntervals = Intervals.size();
	// populate demand for old products
	for (int n = nP; n < N; n++)
	{
		D[n] = new double[T]();
		int num1 = rand() % nIntervals; // choose an interval to generate from
		for (int t = 0; t < Old60 - Olddec; t++)
		{
			D[n][t] = RG.randint(Intervals[num1][0], Intervals[num1][1]);
			//cout << D[n][t] << endl;
		}

		double dec = (Intervals[num1][0] / Olddec) + 10.0;
		int c1 = 0;
		for (int t = Old60 - Olddec; t < Old60; t++)
		{
			c1++;
			double num2 = RG.randint(Intervals[num1][0], Intervals[num1][1]);
			D[n][t] = num2 - c1 * dec;
		}
	}



	// populate demand for new products
	for (int n = 0; n < nP; n++)
	{
		D[n] = new double[T]();
		int num1 = rand() % nIntervals; // choose an interval to generate from
		for (int t = T - 1; t >= T - new60 + NewInc; t--)
		{
			D[n][t] = RG.randint(Intervals[num1][0], Intervals[num1][1]);
		}

		double dec = (Intervals[num1][0] / NewInc) + 10.0;
		int c1 = 0;
		for (int t = T - new60 + NewInc - 1; t >= T - new60; t--)
		{
			c1++;
			double num2 = RG.randint(Intervals[num1][0], Intervals[num1][1]);
			D[n][t] = num2 - c1 * dec;
		}
	}
#pragma endregion
	for (int t = 0; t < T; t++)
	{
		double num1 = 0;
		for (int n = 0; n < N; n++)
		{
			num1 += D[n][t];
		}
		C[t] = (int)(num1 * RG.unifrnd(0.7, 1.2));
	}

	// Fraction of factory resource required to develope product p unifrnd[0.2,0.6]

	for (int p = 0; p < nP; p++)
	{
		H[p] = new double[T]();
		for (int t = 0; t < T; t++)
		{
			double lbh = std::round(0.2 * C[t]);
			double ubh = std::round(0.6 * C[t]);
			H[p][t] = RG.randint(lbh, ubh);
		}


	}
}
