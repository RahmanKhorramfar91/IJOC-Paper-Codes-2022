
#include "ProblemData.h";
#include "Funcs.h";

/* Code summary
Statrt date: 06/11/2019   end date: 3/29/2020
This code used the method proposed in the following paper to solve the bilevel
program of the semiconductor problem:
Rahman Khorramfar, Osman Ozaltin ...
*/
/*
HOW TO SET UP CPLEX FOR C++  :
https://bzdww.com/article/134619/
https://www.youtube.com/watch?v=Hbn1pGWLeaA
1) go to IBM directory in the program files in driver C
2) Go to concert folder -> include and when you see the "ilconcert" folder, copy the directory somewhere
3) Goto cplex folder -> include and when you see the "ilcplex" folder, copy the directory somewhere
4) In the solution Explorer tab, click on the project name and select properties
5) Go to C/C++ general ->" additional include directories" -> paste the two directories:
C:\Program Files\IBM\ILOG\CPLEX_Studio129\concert\include
C:\Program Files\IBM\ILOG\CPLEX_Studio129\cplex\include

6) Go to C/C++ general ->"Preprocessors" and add these words:
WIN32
_CONSOLE
IL_STD
_CRT_SECURE_NO_WARNINGS


Or
NDEBUG
_CONSOLE
IL_STD


7)  In the Project1 property page, select: "c/c++" - "code generation" - "runtime library",
set to "multithreaded DLL (/MD)". determine.

8) In the Project1 property page, select: "Linker" - "Input" - "Additional Dependencies",
and then enter the path of the following three files:
C:\Program Files\IBM\ILOG\CPLEX_Studio129\cplex\lib\x64_windows_vs2017\stat_mda\cplex1290.lib
C:\Program Files\IBM\ILOG\CPLEX_Studio129\cplex\lib\x64_windows_vs2017\stat_mda\ilocplex.lib
C:\Program Files\IBM\ILOG\CPLEX_Studio129\concert\lib\x64_windows_vs2017\stat_mda\concert.lib


9) if you're using visual studio 2017 with cplex 12.8, you may encounter an error which you then may
follow this link: https://www-01.ibm.com/support/docview.wss?uid=ibm10718671

*/

using namespace std;
//double  MasterProblem(vector<Double2D> Z, double** Xs);
//double ENGSubProblem(double** Xh, double** Zh, double* Vh);

int main(int argc, char* argv[]) {
	RandGen RG;
	if (argc > 1)
	{
		ProblemData::T = atoi(argv[1]);
		ProblemData::N = atoi(argv[2]);
		ProblemData::nP = atoi(argv[3]);
		RG.seed = atoi(argv[4]);
	}
	else
	{
		ProblemData::T = 12;
		ProblemData::N = 12;
		ProblemData::nP = 6;
		RG.seed = 731;//4,163,506,731,999,1203
	}
	ProblemData::eps = (double)ProblemData::T / 25;
	//ProblemData::eps = 0;
	std::default_random_engine gen(RG.seed);
	RG.Gen = gen;
	ProblemData::RandomInstanceGenerator(RG);
#pragma region  Fetch Data
	int N = ProblemData::N;
	int T = ProblemData::T;

	int nP = ProblemData::nP;
	double** D = ProblemData::D;
	double* W = ProblemData::W;
	int* DD = ProblemData::DD;
	double** H = ProblemData::H;
	double* pi = ProblemData::pi;

	double b = ProblemData::b; // backorder cost
	double h = ProblemData::h; // holding cost
	double r = ProblemData::r; // production cost
	double* C = ProblemData::C; // total manufacturing capacity
	int Old60 = (T * 0.6);
#pragma endregion	

	for (int t = 0; t < T; t++)
	{
		cout << "\t" << C[t];
	}


#pragma region Problem Parameters and Initial Values
	auto start = chrono::high_resolution_clock::now();

	double LB = 0;
	double UB = 10e12;  // upper bound
	double epsilon = 10e-4; // tolerance
	vector<EngSol> ZV;

	double** Zl = new double* [nP];
	double** Yl = new double* [nP];
	double** Zs = new double* [nP];
	double* Vs = new double[nP]();
	double* Fs = new double[T]();
	double** Ys = new double* [nP];
	double** Xs = new double* [N];
	double gap = -INFINITY;
	double EF_time = 3600;
	int ite = 0;
#pragma endregion


	double profit = IntegratedProblem(Fs,Ys,Xs);
	double MFG_opt = MFG2(Fs,Ys);
	MFG_dual(Ys);
	double ENG_opt = ENGSubProblem(Xs, Zs, Vs);

	/*double status = 1;
	bool IsFeasible = GetFeasibleSol(LB, Zl, Yl, status);
	if (!IsFeasible)
	{
		Print_on_File(RG, ite, 0, UB, 0, 0, gap, Xs, Zl, Yl, IsFeasible, status);
		return 0;
	}
	status = -2;*/




}