#include <ilcplex/ilocplex.h>;
#include "ProblemData.h";
using namespace std;

typedef IloArray<IloNumVarArray> NumVar2D; // to define 2-D decision variables
typedef IloArray<NumVar2D> NumVar3D;  // to define 3-D decision variables
typedef IloArray<NumVar3D> NumVar4D;  // to define 4-D decision variables

void MFG_dual(double** Ys)
{

#pragma region  Fetch Data
	int N = ProblemData::N;
	int T = ProblemData::T;

	int nP = ProblemData::nP;
	double** D = ProblemData::D;
	double* W = ProblemData::W;
	int* DD = ProblemData::DD;
	double** H = ProblemData::H;
	double* pi = ProblemData::pi;

	double b = ProblemData::b; // backorder cost
	double h = ProblemData::h; // holding cost
	double r = ProblemData::r; // production cost
	double* C = ProblemData::C; // total manufacturing capacity
#pragma endregion

	IloEnv env;
	IloModel Model(env);
#pragma region Define extra variables characterized by index j in J + MFG Dual variables

	// MFG Dual variables
	NumVar2D zeta(env, N);
	IloNumVarArray psi(env, T, -IloInfinity, 0, ILOFLOAT);
	NumVar2D theta(env, nP);
	for (int n = 0; n < N; n++)
	{
		zeta[n] = IloNumVarArray(env, T, -IloInfinity, IloInfinity, ILOFLOAT);
	}
	for (int p = 0; p < nP; p++)
	{
		theta[p] = IloNumVarArray(env, T, -IloInfinity, 0, ILOFLOAT);
		//for (int t = 0; t < T; t++)
		//{
		//	//string name = "theta[" + to_string(p) + "][" + to_string(t) + "]";
		//	//const char* name2 = name.c_str();
		//	theta[p][t] = IloNumVar(env, -IloInfinity, 0, ILOFLOAT, name2);
		//}
	}
#pragma endregion


#pragma region Linearize the non-linear term in the MFG-Dual objective function
	NumVar2D tY(env, nP);
	for (int p = 0; p < nP; p++)
	{
		tY[p] = IloNumVarArray(env, T, -IloInfinity, 0, ILOFLOAT);
	}
	double M3 = -10e9;
	for (int p = 0; p < nP; p++)
	{
		for (int t = 0; t < T; t++)
		{
			if (Ys[p][t] == 1)
			{
				Model.add(tY[p][t] == theta[p][t]);
			}
			else
			{
				Model.add(tY[p][t] == 0);
			}
			//Model.add(IloIfThen(env, Ys[p][t] == 1, tY[p][t] == theta[p][t]));
			//Model.add(IloIfThen(env, Ys[p][t] == 0, tY[p][t] == 0));
			//Model.add(tY[p][t] >= M3 * Ys[p][t]);
			//Model.add(tY[p][t] >= theta[p][t]);
			//Model.add(tY[p][t] <= theta[p][t] - M3 * (1 - Ys[p][t]));
		}
	}
#pragma endregion

#pragma region MFG Dual obj
	IloExpr ex_MFG_Dual(env);
	for (int n = 0; n < N; n++)
	{
		if (n < nP)
		{
			for (int t = 0; t < T; t++)
			{
				ex_MFG_Dual += tY[n][t];
			}

		}
		for (int t = 0; t < T; t++)
		{
			ex_MFG_Dual += -zeta[n][t] * D[n][t];
		}
	}
	for (int t = 0; t < T; t++)
	{
		ex_MFG_Dual += psi[t];
	}
	Model.add(IloMaximize(env, ex_MFG_Dual));
#pragma endregion

#pragma region MFG Duals constraint
	// Dual MFG model
	for (int n = 0; n < N; n++)
	{
		for (int t = 0; t < T; t++)
		{
			if (t == T - 1)
			{
				Model.add(zeta[n][t] <= h);
			}
			else
			{
				Model.add(zeta[n][t] - zeta[n][t + 1] <= h);
			}
		}
	}

	for (int p = 0; p < nP; p++)
	{
		for (int t = 0; t < T; t++)
		{
			//for (int j = 0; j < nJ; j++)
			Model.add(-C[t] * zeta[p][t] + psi[t] + theta[p][t] <= r * C[t]);
		}
	}
	for (int n = nP; n < N; n++)
	{
		for (int t = 0; t < T; t++)
		{
			Model.add(-C[t] * zeta[n][t] + psi[t] <= r * C[t]);
		}
	}

	for (int n = 0; n < N; n++)
	{
		for (int t = 0; t < T; t++)
		{
			if (t == T - 1)
			{
				Model.add(-zeta[n][t] <= b);
			}
			else
			{
				Model.add(-zeta[n][t] + zeta[n][t + 1] <= b);
			}
		}
	}
#pragma endregion

	IloCplex cplex(Model);
	cplex.solve();

	double obj = cplex.getObjValue();
	cout << "\t\t MFG_ dual status: " << cplex.getStatus() << endl;
	cout << "\t\t MFG_dual obj: " << obj << endl;


}
double MFG2(double* Fs, double** Ys) {

#pragma region  Fetch Data
	int N = ProblemData::N;
	int T = ProblemData::T;

	int nP = ProblemData::nP;
	double** D = ProblemData::D;
	double* W = ProblemData::W;
	int* DD = ProblemData::DD;
	double** H = ProblemData::H;
	double* pi = ProblemData::pi;

	double b = ProblemData::b; // backorder cost
	double h = ProblemData::h; // holding cost
	double r = ProblemData::r; // production cost
	double* C = ProblemData::C; // total manufacturing capacity
#pragma endregion


#pragma region Define Original Variables
	IloEnv env;
	IloModel Model(env);

	//IloNumVarArray V(env, nP, 0, IloInfinity, ILOFLOAT);
	//IloNumVarArray F(env, T, 0, 1, ILOFLOAT);

	//NumVar2D Psi(env, N);
	NumVar2D B(env, N);
	NumVar2D X(env, N);
	//NumVar2D Y(env, N);
	//NumVar2D Z(env, nP);
	NumVar2D I(env, N);


	for (int n = 0; n < N; n++)
	{
		//Psi[n] = IloNumVarArray(env, T, 0, IloInfinity, ILOFLOAT);
		B[n] = IloNumVarArray(env, T, 0, IloInfinity, ILOFLOAT);
		X[n] = IloNumVarArray(env, T, 0, IloInfinity, ILOFLOAT);
		I[n] = IloNumVarArray(env, T, 0, IloInfinity, ILOFLOAT);
	}

#pragma endregion

#pragma region  Objective Function
	IloExpr ex0(env);
	for (int n = 0; n < N; n++)
	{
		for (int t = 0; t < T; t++)
		{

			ex0 += h * I[n][t];
			ex0 += r * C[t] * X[n][t];
			ex0 += b * B[n][t];

		}
	}

	Model.add(IloMinimize(env, ex0));
	ex0.end();
#pragma endregion


#pragma region Constraints
	// coupling constraint
	/*for (int t = 0; t < T; t++)
	{
		IloExpr exp01(env);
		for (int n = 0; n < N; n++)
		{
			exp01 += X[n][t];
		}
		Model.add(Fs[t] + exp01 == 1);
	}*/

	// MFG 1
	for (int n = 0; n < N; n++)
	{
		for (int t = 0; t < T; t++)
		{
			if (t > 0)
			{
				Model.add(I[n][t] == I[n][t - 1] + C[t] * X[n][t] - (D[n][t] + B[n][t - 1] - B[n][t]));
			}
			else
			{
				Model.add(I[n][t] == C[t] * X[n][t] - (D[n][t] - B[n][t]));
			}
		}
	}

	// MFG 2
	for (int t = 0; t < T; t++)
	{
		IloExpr ex4(env);
		for (int n = 0; n < N; n++)
		{
			ex4 += X[n][t];
		}
		Model.add(ex4 <= 1);
		ex4.end();
	}

	// MFG 3
	for (int p = 0; p < nP; p++)
	{
		for (int t = 0; t < T; t++)
		{
			Model.add(X[p][t] <= Ys[p][t]);
		}
	}


#pragma endregion
	IloCplex cplex(Model);
	cplex.solve();
	double objc = cplex.getObjValue();
	cout << "The optimal MFG value as a follower: " << objc << endl;
	//if (!cplex.solve()) {
	//	env.error() << "Failed to optimize LP." << endl;
	//	throw(-1);
	//}

	////IloNumArray vals(env);
	//env.out() << "MFG Solution status = " << cplex.getStatus() << endl;
	//env.out() << "MFG Solution value = " << cplex.getObjValue() << endl;
	/*double** Xs = new double* [N];
	for (int n = 0; n < N; n++)
	{
		Xs[n] = new double[T]();
		for (int t = 0; t < T; t++)
		{
			Xs[n][t] = std::max(0.0, cplex.getValue(X[n][t]));
			if (Xs[n][t] > 0)
			{
				cout << "X[" << n << "][" << t << "] = " << Xs[n][t] << endl;
			}
		}
	}*/
	return objc;
}




double MFG(double** Xs) {

#pragma region  Fetch Data
	int N = ProblemData::N;
	int T = ProblemData::T;

	int nP = ProblemData::nP;
	double** D = ProblemData::D;
	double* W = ProblemData::W;
	int* DD = ProblemData::DD;
	double** H = ProblemData::H;
	double* pi = ProblemData::pi;

	double b = ProblemData::b; // backorder cost
	double h = ProblemData::h; // holding cost
	double r = ProblemData::r; // production cost
	double* C = ProblemData::C; // total manufacturing capacity
#pragma endregion


#pragma region Define Original Variables
	IloEnv env;
	IloModel Model(env);

	//IloNumVarArray V(env, nP, 0, IloInfinity, ILOFLOAT);
	//IloNumVarArray F(env, T, 0, 1, ILOFLOAT);

	//NumVar2D Psi(env, N);
	NumVar2D B(env, N);
	//NumVar2D X(env, N);
	//NumVar2D Y(env, N);
	//NumVar2D Z(env, nP);
	NumVar2D I(env, N);


	for (int n = 0; n < N; n++)
	{
		//Psi[n] = IloNumVarArray(env, T, 0, IloInfinity, ILOFLOAT);
		B[n] = IloNumVarArray(env, T, 0, IloInfinity, ILOFLOAT);
		//X[n] = IloNumVarArray(env, T, 0, IloInfinity, ILOFLOAT);
		I[n] = IloNumVarArray(env, T, 0, IloInfinity, ILOFLOAT);
	}
	for (int p = 0; p < nP; p++)
	{
		//Z[p] = IloNumVarArray(env, T, 0, 1, ILOBOOL);
	}
#pragma endregion

#pragma region  Objective Function
	IloExpr ex0(env);
	for (int n = 0; n < N; n++)
	{
		for (int t = 0; t < T; t++)
		{

			ex0 += h * I[n][t];
			ex0 += r * C[t] * Xs[n][t];
			ex0 += b * B[n][t];

		}
	}

	Model.add(IloMinimize(env, ex0));
	ex0.end();
#pragma endregion


#pragma region Constraints

	for (int i = 0; i < N; i++)
	{
		for (int t = 0; t < T; t++)
		{
			if (t > 0)
			{
				Model.add(I[i][t] == I[i][t - 1] + C[t] * Xs[i][t] - (D[i][t] + B[i][t - 1] - B[i][t]));
			}
			else
			{
				Model.add(I[i][t] == C[t] * Xs[i][t] - (D[i][t] - B[i][t]));
			}
		}
	}

	//for (int t = 0; t < T; t++)
	//{
	//	IloExpr ex4(env);
	//	for (int n = 0; n < N; n++)
	//	{
	//		ex4 += Xs[n][t];
	//	}
	//	Model.add(ex4 <= 1);
	//	ex4.end();
	//}
	//for (int p = 0; p < nP; p++)
	//{
	//	for (int t = 0; t < T; t++)
	//	{
	//		IloExpr ex5(env);
	//		for (int t2 = 0; t2 <= t; t2++)
	//		{
	//			ex5 += Z[p][t2];
	//		}
	//		Model.add(Xs[p][t] <= ex5);
	//		//Model.add(X[p][t] <= 1);
	//		ex5.end();
	//	}
	//}
#pragma endregion
	IloCplex cplex(Model);
	cplex.solve();
	//if (!cplex.solve()) {
	//	env.error() << "Failed to optimize LP." << endl;
	//	throw(-1);
	//}

	////IloNumArray vals(env);
	//env.out() << "MFG Solution status = " << cplex.getStatus() << endl;
	//env.out() << "MFG Solution value = " << cplex.getObjValue() << endl;
	return cplex.getObjValue();
}





void Print_on_File(RandGen RG, int iter, double cpu_time, double corp, double eng,
	double sp2, double gap, double** X, double** Z, double** Y, bool IsFeasible, double& status)
{

#pragma region  Fetch Data
	int N = ProblemData::N;
	int T = ProblemData::T;

	int nP = ProblemData::nP;
	double** D = ProblemData::D;
	double* W = ProblemData::W;
	int* DD = ProblemData::DD;
	double** H = ProblemData::H;
	double* pi = ProblemData::pi;

	double b = ProblemData::b; // backorder cost
	double h = ProblemData::h; // holding cost
	double r = ProblemData::r; // production cost
	double* C = ProblemData::C; // total manufacturing capacity
	double tolerance = ProblemData::eps;
	double BigM = 10e11;
#pragma endregion

	ofstream fid;
	string name = "ER2W (" + std::to_string(T) + "_" + std::to_string(N) + "_" + to_string(nP) + "_" + to_string(RG.seed) + ") .txt";

	fid.open(name);
	fid << "\n\n" << endl;
	if (!IsFeasible)
	{
		fid << "The problem is not feasible!!!" << endl;
		fid.close();
		return;
	}
	/*else if ((IsFeasible && status == -2))
	{
		fid << "Couldn't solve the LB problem in the given time!" << endl;
		fid.close();
		return;
	}*/


	fid << "\t Number of Iterations: \t" << iter << endl;
	fid << "\t CPU Time (sec): \t" << cpu_time / 1000 << endl;
	fid << "\tCORP Obj (or the best integer): \t" << corp << endl;
	fid << "\tMFG Objective Function Value: \t" << MFG(X) << endl;
	fid << "\tENG Objective Function Value: \t" << eng << endl;
	fid << "\tSP2 Objective Function Value: \t" << sp2 << endl;
	fid << "\t MIP Gap for the last iterations: \t" << gap << endl;
	if (status == -2)
	{
		fid << "\n\tObtain LB within the given time: No" << endl;
	}
	else
	{
		fid << "\n\tObtain LB within the given time: Yes" << endl;
	}
	fid << "\n" << endl;
	double* UsedCap = new double[T]();
	for (int t = 0; t < T; t++)
	{
		//double Ct = 0;
		for (int n = 0; n < N; n++) {
			//if (X[n][t] != 0) { fid << " \t X[" << n << "][" << t << "] = " << X[n][t] << endl; }
			UsedCap[t] += X[n][t];
		}

		fid << " \t C[" << t << "] = " << UsedCap[t] << endl;
	}
	fid << "\n" << endl;
	for (int n = 0; n < nP; n++)
	{
		for (int t = 0; t < T; t++) {
			if (Z[n][t] > 0.5) { fid << " \t Z[" << n << "][" << t << "] = " << Z[n][t] << endl; }
		}
	}
	for (int n = 0; n < nP; n++)
	{
		for (int t = 0; t < T; t++) {
			if (Y[n][t] > 0.5) { fid << " \t Y[" << n << "][" << t << "] = " << Y[n][t] << endl; }
		}
	}
	fid << "\n\n" << endl;
	for (int n = 0; n < N; n++)
	{
		for (int t = 0; t < T; t++) {
			if (X[n][t] != 0) { fid << " \t X[" << n << "][" << t << "] = " << X[n][t] << endl; }
		}
	}




	fid.close();
}