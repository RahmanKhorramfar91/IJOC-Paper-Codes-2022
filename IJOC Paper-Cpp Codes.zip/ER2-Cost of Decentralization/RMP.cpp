#include <ilcplex/ilocplex.h>;
#include "ProblemData.h";
#include "Funcs.h";
using namespace std;
typedef IloArray<IloNumVarArray> NumVar2D; // to define 2-D decision variables
typedef IloArray<NumVar2D> NumVar3D;  // to define 3-D decision variables
typedef IloArray<NumVar3D> NumVar4D;  // to define 4-D decision variables\

double IntegratedProblem(double* Fs, double** Ys,double** Xs)
{

#pragma region  Fetch Data
	int N = ProblemData::N;
	int T = ProblemData::T;

	int nP = ProblemData::nP;
	double** D = ProblemData::D;
	double* W = ProblemData::W;
	int* DD = ProblemData::DD;
	double** H = ProblemData::H;
	double* pi = ProblemData::pi;

	double b = ProblemData::b; // backorder cost
	double h = ProblemData::h; // holding cost
	double r = ProblemData::r; // production cost
	double* C = ProblemData::C; // total manufacturing capacity
	double tolerance = ProblemData::eps;
	//double BigM = 10e10;
	int Old60 = (T * 0.6); // old60 = new60
#pragma endregion	

#pragma region Define Original Variables
	IloEnv env;
	IloModel Model(env);

	IloNumVarArray V(env, nP, 0, IloInfinity, ILOFLOAT);
	IloNumVarArray F(env, T, 0, IloInfinity, ILOFLOAT);
	NumVar2D B(env, N);
	NumVar2D X(env, N);
	NumVar2D Y(env, nP);
	NumVar2D Z(env, nP);
	NumVar2D I(env, N);


	for (int n = 0; n < N; n++)
	{
		B[n] = IloNumVarArray(env, T, 0, IloInfinity, ILOFLOAT);
		X[n] = IloNumVarArray(env, T, 0, 1, ILOFLOAT);
		I[n] = IloNumVarArray(env, T, 0, IloInfinity, ILOFLOAT);
	}

	for (int p = 0; p < nP; p++)
	{
		Z[p] = IloNumVarArray(env, T, 0, 1, ILOBOOL);
		Y[p] = IloNumVarArray(env, T, 0, 1, ILOBOOL);
	}
#pragma endregion

#pragma region Objective Function of the leader
	IloExpr ex0(env);
	for (int n = 0; n < N; n++)
	{
		for (int t = 0; t < T; t++)
		{
			if (t > 0)
			{
				ex0 += pi[n] * D[n][t];
				ex0 += pi[n] * B[n][t - 1];
				ex0 += -pi[n] * B[n][t];
			}
			else
			{
				ex0 += pi[n] * D[n][t];
				ex0 += -pi[n] * B[n][t];
			}
		}
	}
	for (int n = 0; n < N; n++)
	{
		for (int t = 0; t < T; t++)
		{

			ex0 -= h * I[n][t];
			ex0 -= r * C[t] * X[n][t];
			ex0 -= b * B[n][t];

		}
	}
	Model.add(IloMaximize(env, ex0));
	ex0.end();
#pragma endregion

#pragma region Y_t =1 ==> Y_a>t =1
	for (int p = 0; p < nP; p++)
	{
		for (int t = 0; t < T - 1; t++)
		{
			Model.add(Y[p][t] <= Y[p][t + 1]);
		}
	}
#pragma endregion



#pragma region leader and followers Constraints 
	// coupling constraint
	for (int t = 0; t < T; t++)
	{
		IloExpr exp01(env);
		for (int n = 0; n < N; n++)
		{
			exp01 += X[n][t];
		}
		Model.add(F[t] + exp01 == 1);
	}


	//MFG 0 define the Y variable
	for (int p = 0; p < nP; p++)
	{
		for (int t = 0; t < T; t++)
		{
			IloExpr ex0(env);
			for (int t2 = 0; t2 <= t; t2++)
			{
				ex0 += Z[p][t2];
			}
			Model.add(Y[p][t] <= ex0);
			ex0.end();
		}
	}

	// MFG 1
	for (int n = 0; n < N; n++)
	{
		for (int t = 0; t < T; t++)
		{
			if (t > 0)
			{
				Model.add(I[n][t] == I[n][t - 1] + C[t] * X[n][t] - (D[n][t] + B[n][t - 1] - B[n][t]));
			}
			else
			{
				Model.add(I[n][t] == C[t] * X[n][t] - (D[n][t] - B[n][t]));
			}
		}
	}

	// MFG 2
	for (int t = 0; t < T; t++)
	{
		IloExpr ex4(env);
		for (int n = 0; n < N; n++)
		{
			ex4 += X[n][t];
		}
		Model.add(ex4 <= 1);
		ex4.end();
	}

	// MFG 3
	for (int p = 0; p < nP; p++)
	{
		for (int t = 0; t < T; t++)
		{
			Model.add(X[p][t] <= Y[p][t]);
		}
	}


	// Eng1 
	for (int p = 0; p < nP; p++)
	{
		for (int t = 0; t < T; t++)
		{
			IloExpr ex2(env);
			for (int t2 = 0; t2 < t; t2++)
			{
				ex2 += Z[p][t2];
			}
			Model.add(V[p] >= t * (1 - ex2) - DD[p]);
			ex2.end();
		}
	}

	// Eng2
	for (int t = 0; t < T; t++)
	{
		IloExpr ex7(env);
		for (int p = 0; p < nP; p++)
		{
			ex7 += H[p][t] * Z[p][t];
		}
		/*for (int n = 0; n < N; n++)
		{
			ex7 += C[t] * X[n][t];
		}*/
		Model.add(ex7 <= C[t] * F[t]);
		ex7.end();
	}


	// Eng 3
	for (int p = 0; p < nP; p++)
	{
		IloExpr ex0(env);
		for (int t = 0; t < T; t++)
		{
			ex0 += Z[p][t];
		}
		Model.add(ex0 <= 1);
		ex0.end();
	}
#pragma endregion

#pragma region Solve
	IloCplex cplex(Model);
	cplex.setParam(IloCplex::TiLim, 3600);
	//cplex.setParam(IloCplex::EpGap, 0.60);
	//cplex.exportModel("MA_LP.lp");
	//cplex.setOut(env.getNullStream());
	//cplex.setParam(IloCplex::Param::MIP::Strategy::Branch, 1); //Up/down branch selected first (1,-1),  default:automatic (0)
	//cplex.setParam(IloCplex::Param::MIP::Strategy::BBInterval, 7);// 0 to 7
	//cplex.setParam(IloCplex::Param::MIP::Strategy::NodeSelect, 2);//https://www.ibm.com/support/knowledgecenter/SSSA5P_12.9.0/ilog.odms.cplex.help/CPLEX/UsrMan/topics/discr_optim/mip/performance/20_node_seln.html
	//cplex.setParam(IloCplex::Param::MIP::Strategy::VariableSelect, 4);//-1 to 4
	//cplex.setParam(IloCplex::Param::RootAlgorithm, 4); /000 to 6
	if (!cplex.solve()) {

		return -1;
	}

	double obj = cplex.getObjValue();
	double gap = cplex.getMIPRelativeGap();
#pragma endregion

#pragma region Print Results

	for (int t = 0; t < T; t++)
	{
		Fs[t] = cplex.getValue(F[t]);
		/*if (Fs[t] > 0)
		{
			cout << "F[" << t << "] = " << Fs[t] << endl;
		}*/
	}
	for (int p = 0; p < nP; p++)
	{
		Ys[p] = new double[T]();
		for (int t = 0; t < T; t++)
		{
			Ys[p][t] =std::max(0,(int)cplex.getValue(Y[p][t]));
			/*if (cplex.getValue(Z[p][t]) >0)
			{
				cout << "Z[" << p << "][" << t << "] = " << cplex.getValue(Z[p][t]) << endl;
			}*/
		}
	}
	

	double CORP_obj = 0;
	for (int n = 0; n < N; n++)
	{
		Xs[n] = new double[T]();
		for (int t = 0; t < T; t++)
		{			
			Xs[n][t] = cplex.getValue(X[n][t]);
			if (cplex.getValue(X[n][t])>0)
			{
				//cout << cplex.getValue(X[n][t]) << endl;
			}
			if (t > 0)
			{				
				CORP_obj += pi[n] * D[n][t];
				CORP_obj += pi[n] * cplex.getValue(B[n][t - 1]);
				CORP_obj += -pi[n] * cplex.getValue(B[n][t]);
			}
			else
			{
				CORP_obj += pi[n] * D[n][t];
				CORP_obj += -pi[n] * cplex.getValue(B[n][t]);
			}
		}
	}


	double MFG_obj = 0;
	for (int n = 0; n < N; n++)
	{
		for (int t = 0; t < T; t++)
		{

			MFG_obj += h * cplex.getValue(I[n][t]);
			MFG_obj += r * C[t] * cplex.getValue(X[n][t]);
			MFG_obj += b * cplex.getValue(B[n][t]);
		}
	}

	double ENG_obj = 0;
	for (int p = 0; p < nP; p++)
	{
		ENG_obj += W[p] * cplex.getValue(V[p]);
	}
#pragma endregion


	cout << "\t COR Obj: " << CORP_obj << endl;
	cout << "\t MFG Obj: " << MFG_obj << endl;
	cout << "\t ENG Obj: " << ENG_obj << endl;

	return obj;
}
