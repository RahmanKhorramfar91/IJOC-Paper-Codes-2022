#include <ilcplex/ilocplex.h>;
#include "ProblemData.h";
#include "Funcs.h";
using namespace std;
typedef IloArray<IloNumVarArray> NumVar2D; // to define 2-D decision variables
typedef IloArray<NumVar2D> NumVar3D;  // to define 3-D decision variables
typedef IloArray<NumVar3D> NumVar4D;  // to define 4-D decision variables\

struct Node
{
	int period;
	double obj;
	vector<int> DevP;
	vector<int> DevT;
};

// solve the MP for a while, 

double RMP_TimeLimit(vector<EngSol> ZV, double& gap, double EF_time,
	double** Xs, double*** Zs, double*** Ys, double** Fs)
{
#pragma region  Fetch Data
	int N = ProblemData::N;
	int T = ProblemData::T;
	int Num_ENGs = ProblemData::Num_ENGs;

	int nP = ProblemData::nP;
	int nPE = nP / Num_ENGs;
	double** D = ProblemData::D;
	double* W = ProblemData::W;
	int* DD = ProblemData::DD;
	double** H = ProblemData::H;
	double* pi = ProblemData::pi;

	double b = ProblemData::b; // backorder cost
	double h = ProblemData::h; // holding cost
	double r = ProblemData::r; // production cost
	double* C = ProblemData::C; // total manufacturing capacity
	double tolerance = ProblemData::eps;
	//double BigM = 10e10;
	int Old60 = (T * 0.6); // old60 = new60
#pragma endregion	


#pragma region Define Original Variables
	IloEnv env;
	IloModel Model(env);

	//IloNumVarArray V(env, nP, 0, IloInfinity, ILOFLOAT);
	NumVar2D V(env, Num_ENGs);
	NumVar2D B(env, N);
	NumVar2D X(env, N);
	NumVar3D Y(env, Num_ENGs);
	NumVar3D Z(env, Num_ENGs);
	NumVar2D I(env, N);
	NumVar2D F(env, Num_ENGs);
	for (int i = 0; i < Num_ENGs; i++)
	{
		V[i] = IloNumVarArray(env, nP, 0, IloInfinity, ILOFLOAT);
		F[i] = IloNumVarArray(env, T, 0, IloInfinity, ILOFLOAT);
		Y[i] = NumVar2D(env, nPE);
		Z[i] = NumVar2D(env, nPE);
		for (int p = 0; p < nPE; p++)
		{
			Y[i][p] = IloNumVarArray(env, T, 0, 1, ILOBOOL);
			Z[i][p] = IloNumVarArray(env, T, 0, 1, ILOBOOL);
		}
	}

	for (int n = 0; n < N; n++)
	{
		B[n] = IloNumVarArray(env, T, 0, IloInfinity, ILOFLOAT);
		X[n] = IloNumVarArray(env, T, 0, 1, ILOFLOAT);
		I[n] = IloNumVarArray(env, T, 0, IloInfinity, ILOFLOAT);
	}

#pragma endregion

#pragma region Objective Function of the leader
	IloExpr ex0(env);
	for (int n = 0; n < N; n++)
	{
		for (int t = 0; t < T; t++)
		{
			if (t > 0)
			{
				ex0 += pi[n] * D[n][t];
				ex0 += pi[n] * B[n][t - 1];
				ex0 += -pi[n] * B[n][t];
			}
			else
			{
				ex0 += pi[n] * D[n][t];
				ex0 += -pi[n] * B[n][t];
			}
		}
	}

	Model.add(IloMaximize(env, ex0));
	ex0.end();
#pragma endregion

#pragma region Y_t =1 ==> Y_a>t =1 and coupling constraint
	for (int e = 0; e < Num_ENGs; e++)
	{
		for (int p = 0; p < nPE; p++)
		{
			for (int t = 0; t < T - 1; t++)
			{
				Model.add(Y[e][p][t] <= Y[e][p][t + 1]);
			}
		}
	}
	for (int t = 0; t < T; t++)
	{
		IloExpr expf(env);
		IloExpr expX(env);
		for (int e = 0; e < Num_ENGs; e++)
		{
			expf += F[e][t];
		}
		for (int n = 0; n < N; n++)
		{
			expX += X[n][t];
		}
		Model.add(expf + expX == 1);
	}

#pragma endregion


#pragma region leader and followers Constraints 
	//MFG 0 define the Y variable
	for (int e = 0; e < Num_ENGs; e++)
	{
		for (int p = 0; p < nPE; p++)
		{
			for (int t = 0; t < T; t++)
			{
				IloExpr ex0(env);
				for (int t2 = 0; t2 <= t; t2++)
				{
					ex0 += Z[e][p][t2];
				}
				//Model.add(Y[e][p][t] >= ex0);
				Model.add(Y[e][p][t] <= ex0);
				ex0.end();
			}
		}
	}


	// MFG 1
	for (int n = 0; n < N; n++)
	{
		for (int t = 0; t < T; t++)
		{
			if (t > 0)
			{
				Model.add(I[n][t] == I[n][t - 1] + C[t] * X[n][t] - (D[n][t] + B[n][t - 1] - B[n][t]));
			}
			else
			{
				Model.add(I[n][t] == C[t] * X[n][t] - (D[n][t] - B[n][t]));
			}
		}
	}

	// MFG 2
	for (int t = 0; t < T; t++)
	{
		IloExpr ex4(env);
		for (int n = 0; n < N; n++)
		{
			ex4 += X[n][t];
		}
		Model.add(ex4 <= 1);
		ex4.end();
	}

	// MFG 3
	int p2 = 0;
	for (int e = 0; e < Num_ENGs; e++)
	{
		for (int p = 0; p < nPE; p++)
		{

			for (int t = 0; t < T; t++)
			{
				Model.add(X[p2][t] <= Y[e][p][t]);
			}
			p2++;
		}
	}



	// Constraints for each ENG unit 
	//C1:
	for (int e = 0; e < Num_ENGs; e++)
	{
		for (int p = 0; p < nPE; p++)
		{
			for (int t = 0; t < T; t++)
			{
				IloExpr ex2(env);
				for (int t2 = 0; t2 < t; t2++)
				{
					ex2 += Z[e][p][t2];
				}
				Model.add(V[e][p] >= t * (1 - ex2) - DD[p]);
				ex2.end();
			}
		}
	}


	// Eng2
	p2 = 0;
	for (int e = 0; e < Num_ENGs; e++)
	{
		for (int t = 0; t < T; t++)
		{
			IloExpr ex7(env);
			for (int p = 0; p < nPE; p++)
			{
				ex7 += H[p2 + p][t] * Z[e][p][t];
			}
			/*for (int n = 0; n < N; n++)
			{
				ex7 += C[t] * X[n][t];
			}*/
			Model.add(ex7 <= C[t] * F[e][t]);
			ex7.end();
		}
		p2 = p2 + nPE;
	}



	// Eng 3
	for (int e = 0; e < Num_ENGs; e++)
	{
		for (int p = 0; p < nPE; p++)
		{
			IloExpr ex0(env);
			for (int t = 0; t < T; t++)
			{
				ex0 += Z[e][p][t];
			}
			Model.add(ex0 <= 1);
			ex0.end();
		}
	}

#pragma endregion

#pragma region Define extra variables characterized by index j in J + MFG Dual variables
	int nJ = ZV.size();
	//NumVar3D Vp(env, Num_ENGs);
	//NumVar3D nu(env, Num_ENGs);

	for (int e = 0; e < Num_ENGs; e++)
	{
		//Vp[e] = NumVar2D(env, nJ);
		//nu[e] = NumVar2D(env, nJ);
		for (int j = 0; j < nJ; j++)
		{
			//nu[e][j] = IloNumVarArray(env, T, 0, 1, ILOBOOL);
		}
	}


	// MFG Dual variables
	NumVar2D zeta(env, N);
	IloNumVarArray psi(env, T, -IloInfinity, 0, ILOFLOAT);
	NumVar2D theta(env, nP);
	for (int n = 0; n < N; n++)
	{
		zeta[n] = IloNumVarArray(env, T, -IloInfinity, IloInfinity, ILOFLOAT);
	}
	for (int p = 0; p < nP; p++)
	{
		theta[p] = IloNumVarArray(env, T, -IloInfinity, 0, ILOFLOAT);
		//for (int t = 0; t < T; t++)
		//{
		//	//string name = "theta[" + to_string(p) + "][" + to_string(t) + "]";
		//	//const char* name2 = name.c_str();
		//	theta[p][t] = IloNumVar(env, -IloInfinity, 0, ILOFLOAT, name2);
		//}
	}
#pragma endregion

#pragma region Generated Constraints for ENG model	
	NumVar3D gamma(env, nJ);

	for (int j = 0; j < nJ; j++)
	{
		gamma[j] = NumVar2D(env, Num_ENGs);
		for (int e = 0; e < Num_ENGs; e++)
		{
			gamma[j][e] = IloNumVarArray(env, T, 0, 1, ILOBOOL);
		}
	}
	double M2 = 0;
	for (int p = 0; p < nP; p++)
	{
		M2 += W[p] * (T - DD[p]);
	}
	for (int j = 0; j < nJ; j++)
	{
		int p2 = 0;
		for (int e = 0; e < Num_ENGs; e++)
		{
			IloExpr eng(env);
			for (int p = 0; p < nPE; p++)
			{
				eng += W[p2] * V[e][p];
				eng -= W[p2] * ZV[j].V[e][p];
				p2++;
			}
			for (int t = 0; t < T; t++)
			{
				eng -= M2 * gamma[j][e][t];
			}
			Model.add(eng <= 0);
			eng.end();

		}

	}

	for (int j = 0; j < nJ; j++)
	{
		int p2 = 0;
		for (int e = 0; e < Num_ENGs; e++)
		{
			for (int t = 0; t < T; t++)
			{
				double Hbar = 0;
				for (int p = 0; p < nPE; p++)
				{
					Hbar += H[p2 + p][t] * ZV[j].Z[e][p][t];
				}

				//IloExpr eng1(env);
				/*for (int n = 0; n < N; n++)
				{
					eng1 += C[t] * X[n][t];
				}*/
				Model.add(C[t] * F[e][t] >= Hbar * (1 - gamma[j][e][t]));
				Model.add(C[t] * F[e][t] <= Hbar - gamma[j][e][t] + C[t] * (1 - gamma[j][e][t]));
				//Model.add(IloIfThen(env, gamma[j][t] == 0, Hbar <= C[t] - eng1));		
				//Model.add(IloIfThen(env, gamma[j][t] == 1, Hbar - 1 >= C[t] - eng1));				
			}
			p2 = p2 + nPE;
		}
	}

#pragma endregion

#pragma region MFG Duals constraint
	// Dual MFG model
	for (int n = 0; n < N; n++)
	{
		for (int t = 0; t < T; t++)
		{
			if (t == T - 1)
			{
				Model.add(zeta[n][t] <= h);
			}
			else
			{
				Model.add(zeta[n][t] - zeta[n][t + 1] <= h);
			}
		}
	}

	for (int p = 0; p < nP; p++)
	{
		for (int t = 0; t < T; t++)
		{
			//for (int j = 0; j < nJ; j++)
			Model.add(-C[t] * zeta[p][t] + psi[t] + theta[p][t] <= r * C[t]);
		}
	}
	for (int n = nP; n < N; n++)
	{
		for (int t = 0; t < T; t++)
		{
			Model.add(-C[t] * zeta[n][t] + psi[t] <= r * C[t]);
		}
	}

	for (int n = 0; n < N; n++)
	{
		for (int t = 0; t < T; t++)
		{
			if (t == T - 1)
			{
				Model.add(-zeta[n][t] <= b);
			}
			else
			{
				Model.add(-zeta[n][t] + zeta[n][t + 1] <= b);
			}
		}
	}
#pragma endregion

#pragma region Linearize the non-linear term in the MFG-Dual objective function
	NumVar2D tY(env, nP);
	for (int p = 0; p < nP; p++)
	{
		tY[p] = IloNumVarArray(env, T, -IloInfinity, 0, ILOFLOAT);
	}
	double M3 = -10e8;
	p2 = 0;
	for (int e = 0; e < Num_ENGs; e++)
	{
		for (int p = 0; p < nPE; p++)
		{
			for (int t = 0; t < T; t++)
			{
				//Model.add(IloIfThen(env, Y[p][t] == 1, tY[p][t] == theta[p][t]));
				//Model.add(IloIfThen(env, Y[p][t] == 0, tY[p][t] == 0));
				Model.add(tY[p2][t] >= M3 * Y[e][p][t]);
				Model.add(tY[p2][t] >= theta[p2][t]);
				Model.add(tY[p2][t] <= theta[p2][t] - M3 * (1 - Y[e][p][t]));
			}
			p2++;
		}
	}

#pragma endregion

#pragma region Strong duality 
	IloExpr ex_MFG(env);
	for (int n = 0; n < N; n++)
	{
		for (int t = 0; t < T; t++)
		{

			ex_MFG += h * I[n][t];
			ex_MFG += r * C[t] * X[n][t];
			ex_MFG += b * B[n][t];

		}
	}

	IloExpr ex_MFG_Dual(env);
	for (int n = 0; n < N; n++)
	{
		if (n < nP)
		{
			for (int t = 0; t < T; t++)
			{
				ex_MFG_Dual += tY[n][t];
			}

		}
		for (int t = 0; t < T; t++)
		{
			ex_MFG_Dual += -zeta[n][t] * D[n][t];
		}
	}
	for (int t = 0; t < T; t++)
	{
		ex_MFG_Dual += psi[t];
	}

	Model.add(IloAbs(-ex_MFG_Dual + ex_MFG) <= tolerance);
	ex_MFG.end();
	ex_MFG_Dual.end();
#pragma endregion

	IloCplex cplex(Model);


#pragma region Solve the model
	cplex.setParam(IloCplex::TiLim, EF_time);
	//cplex.setParam(IloCplex::EpGap, 0.001);
	//cplex.exportModel("MA_LP.lp");
   // cplex.setOut(env.getNullStream());
	//cplex.setParam(IloCplex::Param::MIP::Strategy::Branch, 1); //Up/down branch selected first (1,-1),  default:automatic (0)
	//cplex.setParam(IloCplex::Param::MIP::Strategy::BBInterval, 7);// 0 to 7
	//cplex.setParam(IloCplex::Param::MIP::Strategy::NodeSelect, 2);//https://www.ibm.com/support/knowledgecenter/SSSA5P_12.9.0/ilog.odms.cplex.help/CPLEX/UsrMan/topics/discr_optim/mip/performance/20_node_seln.html
	//cplex.setParam(IloCplex::Param::MIP::Strategy::VariableSelect, 4);//-1 to 4
	//cplex.setParam(IloCplex::Param::RootAlgorithm, 4); /000 to 6
	if (!cplex.solve()) {
		Model.end();
		cplex.end();
		// set the feasible solution to the Zl,Yl				
		return -1;
	}

	double obj = cplex.getObjValue();
	gap = cplex.getMIPRelativeGap();


	// get the value of X
	for (int n = 0; n < N; n++)
	{
		Xs[n] = new double[T]();
		for (int t = 0; t < T; t++)
		{
			Xs[n][t] = cplex.getValue(X[n][t]);
		}
	}
	// get Zs and Ys, Fs
	for (int e = 0; e < Num_ENGs; e++)
	{
		Zs[e] = new double* [nPE];
		Ys[e] = new double* [nPE];
		Fs[e] = new double[T]();
		for (int n = 0; n < nPE; n++)
		{
			Zs[e][n] = new double[T]();
			Ys[e][n] = new double[T]();
			for (int t = 0; t < T; t++)
			{
				Zs[e][n][t] = cplex.getValue(Z[e][n][t]);
				Ys[e][n][t] = cplex.getValue(Y[e][n][t]);
				Fs[e][t] = cplex.getValue(F[e][t]);
			}
		}
	}


#pragma endregion

	Model.end();
	cplex.end();

	return obj;
}


double RMP_Solution_Engine(vector<EngSol> ZV, double** Xs,
	double*** Zs, double*** Ys, double& gap,
	double EF_time, double** Fs)
{

#pragma region  Fetch Data
	int N = ProblemData::N;
	int T = ProblemData::T;

	int nP = ProblemData::nP;
	double** D = ProblemData::D;
	double* W = ProblemData::W;
	int* DD = ProblemData::DD;
	double** H = ProblemData::H;
	double* pi = ProblemData::pi;

	double b = ProblemData::b; // backorder cost
	double h = ProblemData::h; // holding cost
	double r = ProblemData::r; // production cost
	double* C = ProblemData::C; // total manufacturing capacity
	double tolerance = ProblemData::eps;
	//double BigM = 10e7;
	int Old60 = (T * 0.6); // old60 = new60
#pragma endregion	

	double Corp_obj0 = 0;
	Corp_obj0 = RMP_TimeLimit(ZV, gap, 3600, Xs, Zs, Ys, Fs);
	if (gap < 0.001 && Corp_obj0 != -1) { return Corp_obj0; }

	return Corp_obj0;
}



double RMP_ENG_Obj(double** z, int e_num)
{

#pragma region  Fetch Data
	int N = ProblemData::N;
	int T = ProblemData::T;
	int Num_ENGs = ProblemData::Num_ENGs;

	int nP = ProblemData::nP;
	int nPE = nP / Num_ENGs;
	double** D = ProblemData::D;
	double* W = ProblemData::W;
	int* DD = ProblemData::DD;
	double** H = ProblemData::H;
	double* pi = ProblemData::pi;

	double b = ProblemData::b; // backorder cost
	double h = ProblemData::h; // holding cost
	double r = ProblemData::r; // production cost
	double* C = ProblemData::C; // total manufacturing capacity
#pragma endregion


	int* V = new int[nP]();
	double RMP_ENG_obj_value = 0;


	//	Model.add(V[p] >= t * (1 - ex2) - DD[p]);

	int p2 = e_num * nPE;
	for (int p = 0; p < nPE; p++)
	{
		for (int t = 0; t < T; t++)
		{
			int Acummul = 0;
			for (int t2 = 0; t2 < t; t2++)
			{
				Acummul += z[p][t2];
			}
			V[p] = std::max(V[p], t * (1 - Acummul) - DD[p2]);
		}
		RMP_ENG_obj_value += V[p] * W[p2];
		p2++;
	}
	return RMP_ENG_obj_value;
}