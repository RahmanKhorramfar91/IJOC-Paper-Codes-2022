#include "ProblemData.h";
#include <ilcplex/ilocplex.h>;
using namespace std;
// implementation of UpdateLowerBound function in Models header


typedef IloArray<IloNumVarArray> NumVar2D; // to define 2-D decision variables
typedef IloArray<NumVar2D> NumVar3D;  // to define 3-D decision variables
typedef IloArray<NumVar3D> NumVar4D;  // to define 4-D decision variables

double MFG_ENG_SP2(double** Xs,double** Fs, int e_num) {

#pragma region  Fetch Data
	int N = ProblemData::N;
	int T = ProblemData::T;
	int Num_ENGs = ProblemData::Num_ENGs;

	int nP = ProblemData::nP;
	int nPE = nP / Num_ENGs;
	double** D = ProblemData::D;
	double* W = ProblemData::W;
	int* DD = ProblemData::DD;
	double** H = ProblemData::H;
	double* pi = ProblemData::pi;

	double b = ProblemData::b; // backorder cost
	double h = ProblemData::h; // holding cost
	double r = ProblemData::r; // production cost
	double* C = ProblemData::C; // total manufacturing capacity
#pragma endregion


#pragma region Define Original Variables
	IloEnv env;
	IloModel Model(env);
	IloNumVarArray V(env, nP, 0, IloInfinity);

	NumVar2D Z(env, nP);
	for (int p = 0; p < nP; p++) { Z[p] = IloNumVarArray(env, T, 0, 1, ILOBOOL); }
#pragma endregion

#pragma region  Objective Function	
	IloExpr ex0(env);
	int p2 = e_num * nPE;
	for (int p = 0; p < nPE; p++)
	{
		ex0 += W[p2] * V[p];
		p2++;
	}

	Model.add(IloMinimize(env, ex0));
	ex0.end();
#pragma endregion


#pragma region Constraints
	// MFG 1: MFg Feasibility constraint
	p2 = e_num * nPE;
	for (int p = 0; p < nPE; p++)
	{
		for (int t = 0; t < T; t++)
		{
			IloExpr ex5(env);
			for (int t2 = 0; t2 <= t; t2++)
			{
				ex5 += Z[p][t2];
			}
			Model.add(Xs[p2][t] <= ex5);
			ex5.end();
		}
		p2++;
	}

	//Eng1: get the tardiness
	for (int p = 0; p < nPE; p++)
	{
		for (int t = 0; t < T; t++)
		{
			IloExpr ex2(env);
			for (int t2 = 0; t2 < t; t2++)
			{
				ex2 += Z[p][t2];
			}
			Model.add(V[p] >= t * (1 - ex2) - DD[p]);
			ex2.end();
		}
	}

	//Eng2: Factory Capacity	
	for (int t = 0; t < T; t++)
	{
		int p2 = e_num * nPE;
		IloExpr ex1(env);
		for (int p = 0; p < nPE; p++)
		{
			ex1 += H[p2][t] * Z[p][t];
			p2++;
		}
		double rhs =0;
		//for (int n = 0; n < N; n++)

		rhs = std::max(0.0, C[t] * Fs[e_num][t]);
		Model.add(ex1 <= rhs);
		ex1.end();
	}
	// Eng3: products developed at most once
	for (int p = 0; p < nPE; p++)
	{
		IloExpr ex0(env);
		for (int t = 0; t < T; t++)
		{
			ex0 += Z[p][t];
		}
		Model.add(ex0 <= 1);
		ex0.end();
	}

#pragma endregion


	IloCplex cplex(Model);
	cplex.setOut(env.getNullStream());
	if (!cplex.solve()) {
		//env.error() << "Failed to optimize SP2" << endl;
		return -INFINITY;
	}
	env.out() << "\t SP2 objective = " << cplex.getObjValue() << endl;
	double obj0 = cplex.getObjValue();
#pragma region Print Solution
	/*for (int p = 0; p < nP; p++)
	{
		for (int t = 0; t < T; t++)
		{
			if ((double)cplex.getValue(Z[p][t]) >= 0.5)
			{
				cout << "\t Z[" << p << "][" << t << "] = " << cplex.getValue(Z[p][t]) << endl;
			}

		}
	}

	for (int p = 0; p < nP; p++)
	{
		cout << "\t V[" << p << "] = " << cplex.getValue(V[p]) << endl;
	}*/
#pragma endregion
	Model.end();
	cplex.end();

	return obj0;

}
