
#include "ProblemData.h";
#include "Funcs.h";

/* Code summary
Statrt date: 06/11/2019   end date: 3/29/2020
This code used the method proposed in the following paper to solve the bilevel
program of the semiconductor problem:
Rahman Khorramfar, Osman Ozaltin ...
*/
/*
HOW TO SET UP CPLEX FOR C++  :
https://bzdww.com/article/134619/
https://www.youtube.com/watch?v=Hbn1pGWLeaA
1) go to IBM directory in the program files in driver C
2) Go to concert folder -> include and when you see the "ilconcert" folder, copy the directory somewhere
3) Goto cplex folder -> include and when you see the "ilcplex" folder, copy the directory somewhere
4) In the solution Explorer tab, click on the project name and select properties
5) Go to C/C++ general ->" additional include directories" -> paste the two directories:
C:\Program Files\IBM\ILOG\CPLEX_Studio129\concert\include
C:\Program Files\IBM\ILOG\CPLEX_Studio129\cplex\include

6) Go to C/C++ general ->"Preprocessors" and add these words:
WIN32
_CONSOLE
IL_STD
_CRT_SECURE_NO_WARNINGS


Or
NDEBUG
_CONSOLE
IL_STD


7)  In the Project1 property page, select: "c/c++" - "code generation" - "runtime library",
set to "multithreaded DLL (/MD)". determine.

8) In the Project1 property page, select: "Linker" - "Input" - "Additional Dependencies",
and then enter the path of the following three files:
C:\Program Files\IBM\ILOG\CPLEX_Studio129\cplex\lib\x64_windows_vs2017\stat_mda\cplex1290.lib
C:\Program Files\IBM\ILOG\CPLEX_Studio129\cplex\lib\x64_windows_vs2017\stat_mda\ilocplex.lib
C:\Program Files\IBM\ILOG\CPLEX_Studio129\concert\lib\x64_windows_vs2017\stat_mda\concert.lib


9) if you're using visual studio 2017 with cplex 12.8, you may encounter an error which you then may
follow this link: https://www-01.ibm.com/support/docview.wss?uid=ibm10718671

*/

using namespace std;
//double  MasterProblem(vector<Double2D> Z, double** Xs);
//double ENGSubProblem(double** Xh, double** Zh, double* Vh);

int main(int argc, char* argv[]) {
	RandGen RG;
	if (argc > 1)
	{
		ProblemData::T = atoi(argv[1]);
		ProblemData::N = atoi(argv[2]);
		ProblemData::nP = atoi(argv[3]);
		RG.seed = atoi(argv[4]);
		ProblemData::Num_ENGs = atoi(argv[5]);
	}
	else
	{
		ProblemData::T = 12;
		ProblemData::N = 14;
		ProblemData::nP = 4;
		RG.seed = 1203;//4,163,506,731,999,1203
		ProblemData::Num_ENGs = 2;
	}
	ProblemData::eps = (double)ProblemData::T; // for large scale problems
	//ProblemData::eps = 500.0;
	std::default_random_engine gen(RG.seed);
	RG.Gen = gen;
	ProblemData::RandomInstanceGenerator(RG);

#pragma region  Fetch Data
	int N = ProblemData::N;
	int T = ProblemData::T;
	int Num_ENGs = ProblemData::Num_ENGs;

	int nP = ProblemData::nP;
	int nPE = nP / Num_ENGs;
	double** D = ProblemData::D;
	double* W = ProblemData::W;
	int* DD = ProblemData::DD;
	double** H = ProblemData::H;
	double* pi = ProblemData::pi;

	double b = ProblemData::b; // backorder cost
	double h = ProblemData::h; // holding cost
	double r = ProblemData::r; // production cost
	double* C = ProblemData::C; // total manufacturing capacity
#pragma endregion





#pragma region Problem Parameters and Initial Values
	auto start = chrono::high_resolution_clock::now();


	double LB = 0;
	double UB = 10e12;  // upper bound
	double epsilon = 10e-4; // tolerance
	vector<EngSol> ZV;


	double*** Zs = new double** [Num_ENGs];
	double** Vs = new double* [Num_ENGs]();
	double** Fs = new double* [Num_ENGs]();
	double*** Ys = new double** [Num_ENGs];
	double** Xs = new double* [N];
	double gap = -INFINITY;
	double EF_time = 3600;
	int ite = 0;
#pragma endregion

	ofstream fid;
	fid.open("Bilevel_ENG_MFG_F1_Multiple_ENGs_Results.txt", std::ios::app);
	fid << T << "-" << N << "-" << nP << "-" << RG.seed << "-" << Num_ENGs << "-";

	while (true)
	{
		ite++; gap = INFINITY;
		double corp_obj = RMP_Solution_Engine(ZV, Xs, Zs, Ys, gap, EF_time, Fs);

		UB = INFINITY;
		double* RMP_eng = new double[Num_ENGs]();
		double* ENGobj = new double[Num_ENGs]();
		double* SP2Obj = new double[Num_ENGs]();
		if (gap < 0.001)
		{
			UB = corp_obj;


			for (int e = 0; e < Num_ENGs; e++)
			{
				RMP_eng[e] = RMP_ENG_Obj(Zs[e], e);
				ENGobj[e] = -INFINITY;
				SP2Obj[e] = INFINITY;
				ENGobj[e] = ENGSubProblem(Fs, Zs, Vs, e);
				if (RMP_eng[e] <= ENGobj[e])
				{
					SP2Obj[e] = RMP_eng[e];
				}
				else
				{
					SP2Obj[e] = MFG_ENG_SP2(Xs, Fs, e);
				}
			}
		}

		bool is_opt = true;
		for (int e = 0; e < Num_ENGs; e++)
		{
			if (abs(SP2Obj[e] - ENGobj[e]) >= epsilon)
			{
				is_opt = false; break;
			}
		}

		auto end = chrono::high_resolution_clock::now();
		auto Elapsed = chrono::duration_cast<chrono::milliseconds>(end - start);
		double duration = Elapsed.count();
		std::cout << "\n\n Iteration " << ite << "\t MP Obj: " << UB <<
			"\t Is optimal: " << is_opt << endl;
		std::cout << "Time: " << Elapsed.count() << endl;;
		std::cout << endl;
		if (is_opt || duration > 7.2e6 || std::abs(UB) == INFINITY)
		{
			//string name = "ER2W (" + std::to_string(T) + "_" + std::to_string(N) + "_" + to_string(nP) + "_" + to_string(RG.seed) + ") .txt";
			fid << "Iteration: " << ite << "\tCPU: " << Elapsed.count()/1000 <<"\t Opt?: "<<is_opt<<endl;
			break;
		}
		else
		{
			//EngSol *newZV =  new EngSol(Zh, Vh);
			double*** Znew = new double** [Num_ENGs];
			double** Vnew = new double* [Num_ENGs];
			for (int e = 0; e < Num_ENGs; e++)
			{
				Znew[e] = new double* [nPE];
				Vnew[e] = new double[nPE]();
				for (int p = 0; p < nPE; p++)
				{
					Znew[e][p] = new double[T]();
					Vnew[e][p] = Vs[e][p];
					for (int t = 0; t < T; t++)
					{
						Znew[e][p][t] = Zs[e][p][t];
					}
				}
			}

			EngSol newZV(Znew, Vnew);
			ZV.push_back(newZV);
			//ZV.push_back(EngSol());
			//ZV[ZV.size() - 1].Z = Zh;
			//ZV[ZV.size() - 1].V = Vh;
			//delete newZV;
		}
	}


}