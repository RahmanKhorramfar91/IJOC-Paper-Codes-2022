#include <ilcplex/ilocplex.h>;
#include "ProblemData.h";
using namespace std;

typedef IloArray<IloNumVarArray> NumVar2D; // to define 2-D decision variables
typedef IloArray<NumVar2D> NumVar3D;  // to define 3-D decision variables
typedef IloArray<NumVar3D> NumVar4D;  // to define 4-D decision variables

double MFG(double** Xs) {

#pragma region  Fetch Data
	int N = ProblemData::N;
	int T = ProblemData::T;

	int nP = ProblemData::nP;
	double** D = ProblemData::D;
	double* W = ProblemData::W;
	int* DD = ProblemData::DD;
	double** H = ProblemData::H;
	double* pi = ProblemData::pi;

	double b = ProblemData::b; // backorder cost
	double h = ProblemData::h; // holding cost
	double r = ProblemData::r; // production cost
	double* C = ProblemData::C; // total manufacturing capacity
#pragma endregion


#pragma region Define Original Variables
	IloEnv env;
	IloModel Model(env);

	//IloNumVarArray V(env, nP, 0, IloInfinity, ILOFLOAT);
	//IloNumVarArray F(env, T, 0, 1, ILOFLOAT);

	//NumVar2D Psi(env, N);
	NumVar2D B(env, N);
	//NumVar2D X(env, N);
	//NumVar2D Y(env, N);
	//NumVar2D Z(env, nP);
	NumVar2D I(env, N);


	for (int n = 0; n < N; n++)
	{
		//Psi[n] = IloNumVarArray(env, T, 0, IloInfinity, ILOFLOAT);
		B[n] = IloNumVarArray(env, T, 0, IloInfinity, ILOFLOAT);
		//X[n] = IloNumVarArray(env, T, 0, IloInfinity, ILOFLOAT);
		I[n] = IloNumVarArray(env, T, 0, IloInfinity, ILOFLOAT);
	}
	for (int p = 0; p < nP; p++)
	{
		//Z[p] = IloNumVarArray(env, T, 0, 1, ILOBOOL);
	}
#pragma endregion

#pragma region  Objective Function
	IloExpr ex0(env);
	for (int n = 0; n < N; n++)
	{
		for (int t = 0; t < T; t++)
		{

			ex0 += h * I[n][t];
			ex0 += r * C[t] * Xs[n][t];
			ex0 += b * B[n][t];

		}
	}

	Model.add(IloMinimize(env, ex0));
	ex0.end();
#pragma endregion


#pragma region Constraints

	for (int i = 0; i < N; i++)
	{
		for (int t = 0; t < T; t++)
		{
			if (t > 0)
			{
				Model.add(I[i][t] == I[i][t - 1] + C[t] * Xs[i][t] - (D[i][t] + B[i][t - 1] - B[i][t]));
			}
			else
			{
				Model.add(I[i][t] == C[t] * Xs[i][t] - (D[i][t] - B[i][t]));
			}
		}
	}

	//for (int t = 0; t < T; t++)
	//{
	//	IloExpr ex4(env);
	//	for (int n = 0; n < N; n++)
	//	{
	//		ex4 += Xs[n][t];
	//	}
	//	Model.add(ex4 <= 1);
	//	ex4.end();
	//}
	//for (int p = 0; p < nP; p++)
	//{
	//	for (int t = 0; t < T; t++)
	//	{
	//		IloExpr ex5(env);
	//		for (int t2 = 0; t2 <= t; t2++)
	//		{
	//			ex5 += Z[p][t2];
	//		}
	//		Model.add(Xs[p][t] <= ex5);
	//		//Model.add(X[p][t] <= 1);
	//		ex5.end();
	//	}
	//}
#pragma endregion
	IloCplex cplex(Model);
	cplex.solve();
	//if (!cplex.solve()) {
	//	env.error() << "Failed to optimize LP." << endl;
	//	throw(-1);
	//}

	////IloNumArray vals(env);
	//env.out() << "MFG Solution status = " << cplex.getStatus() << endl;
	//env.out() << "MFG Solution value = " << cplex.getObjValue() << endl;
	return cplex.getObjValue();
}




void Print_on_File2(RandGen RG, int iter, double cpu_time, double corp, double eng,
	double sp2, double gap, double** X, double** Z, double** Y, bool IsFeasible, double& status)
{

#pragma region  Fetch Data
	int N = ProblemData::N;
	int T = ProblemData::T;

	int nP = ProblemData::nP;
	double** D = ProblemData::D;
	double* W = ProblemData::W;
	int* DD = ProblemData::DD;
	double** H = ProblemData::H;
	double* pi = ProblemData::pi;

	double b = ProblemData::b; // backorder cost
	double h = ProblemData::h; // holding cost
	double r = ProblemData::r; // production cost
	double* C = ProblemData::C; // total manufacturing capacity
	double tolerance = ProblemData::eps;
	double BigM = 10e11;
#pragma endregion

	ofstream fid;
	//string name = "ER2W (" + std::to_string(T) + "_" + std::to_string(N) + "_" + to_string(nP) + "_" + to_string(RG.seed) + ") .txt";

	fid.open("Bilevel_ENG_MFG_F1_Multiple_ENGs_Results.txt",std::ios::app);
	fid << T << "-" << N << "-" << nP<<"-"<<RG.seed<<"-";
	//fid << "\n\n" << endl;
	if (!IsFeasible)
	{
		fid << " not Feasible" << endl;
		fid.close();
		return;
	}
	/*else if ((IsFeasible && status == -2))
	{
		fid << "Couldn't solve the LB problem in the given time!" << endl;
		fid.close();
		return;
	}*/


	fid << "Iter:" << iter;
	fid << "\t CPU (sec): " << cpu_time / 1000;
	fid << "\t CORP Obj: " << corp;
	fid << "\t MFG Obj: " << MFG(X);
	fid << "\t ENG Obj: " << eng;
	fid << "\t SP2 Obj: " << sp2;
	fid << "\t MIP Gap: " << gap;
	if (status == -2)
	{
		fid << "\t LB: No" << endl;
	}
	else
	{
		fid << "\t LB: Yes" << endl;
	}
	//fid << "\n" << endl;
	//double* UsedCap = new double[T]();
	//for (int t = 0; t < T; t++)
	//{
	//	//double Ct = 0;
	//	for (int n = 0; n < N; n++) {
	//		//if (X[n][t] != 0) { fid << " \t X[" << n << "][" << t << "] = " << X[n][t] << endl; }
	//		UsedCap[t] += X[n][t];
	//	}
	//	fid << " \t C[" << t << "] = " << UsedCap[t] << endl;
	//}
	/*fid << "\n" << endl;
	for (int n = 0; n < nP; n++)
	{
		for (int t = 0; t < T; t++) {
			if (Z[n][t] > 0.5) { fid << " \t Z[" << n << "][" << t << "] = " << Z[n][t] << endl; }
		}
	}
	for (int n = 0; n < nP; n++)
	{
		for (int t = 0; t < T; t++) {
			if (Y[n][t] > 0.5) { fid << " \t Y[" << n << "][" << t << "] = " << Y[n][t] << endl; }
		}
	}
	fid << "\n\n" << endl;
	for (int n = 0; n < N; n++)
	{
		for (int t = 0; t < T; t++) {
			if (X[n][t] != 0) { fid << " \t X[" << n << "][" << t << "] = " << X[n][t] << endl; }
		}
	}*/
	fid.close();
}


