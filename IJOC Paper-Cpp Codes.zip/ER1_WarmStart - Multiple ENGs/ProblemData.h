#pragma once
#pragma once
#include <iostream>;  // for  cout cin
#include <vector>; 
#include<random>;
#include <string>;
#include <fstream>; // to read and write from/on files
#include <cstdio>;  // for puts and printf
#include <cstdlib>; // for string converstion, rand srand, dynamic memory management (C++ header)
#include <iterator>;
#include<math.h>;
#include<chrono>; // for high resolution timing (elapsed time in microseconds and so on)
#include<array>;
#include<list>;
#include<numeric>;
//#include<stdlib.h>; // almost same as cstdlib (C header)

struct EngSol
{
	double*** Z;
	double** V;
	EngSol(double*** vals1, double** vals2) {
		this->Z = vals1;
		this->V = vals2;
	}
	EngSol() {}
};

class RandGen
{
public:
	int seed;
	int randint(int a, int b);
	double unifrnd(double a, double b);
	std::default_random_engine Gen;
	RandGen(double sd) {
		this->seed = sd;
		Gen.seed(sd);
	}
	RandGen() {}
	~RandGen() {}
private:

};


class ProblemData
{
public:
	static int T; // number of periods
	static int N; // number of all products (old+new)
	static int Num_ENGs; // number of all engineering units

	static double r; // production cost of product p at period t (same for all products and times)
	static double h; // per unit holding cost (same for all products and times)
	static double b; // per unit backordering cost (same for all product and times)

	static double* C; // Factory capacity [at period t]

	static int seed; // Seed of the random number generator

	static double** D; // Demand of products
	static int* DD; // due dates
	static double** H; // required manufacturing capacity
	static double* pi; // profit from each product

	static double* W; // penalty cost for delay
	static int nP; // number of new poructs

//	static double** GetD();

	static double eps; // tolerance
	static void RandomInstanceGenerator(RandGen RG);
	ProblemData() {}
	~ProblemData() {}
};


