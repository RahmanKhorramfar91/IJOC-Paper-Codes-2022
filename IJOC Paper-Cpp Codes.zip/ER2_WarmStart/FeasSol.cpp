#include <ilcplex/ilocplex.h>;
#include "ProblemData.h";
#include "Funcs.h";

typedef IloArray<IloNumVarArray> NumVar2D; // to define 2-D decision variables

void MKP_Heuristic(int MinT, double CapCoef, double** Zl)
{

#pragma region  Fetch Data
	int N = ProblemData::N;
	int T = ProblemData::T;
	int nP = ProblemData::nP;
	double** D = ProblemData::D;
	double* W = ProblemData::W;
	int* DD = ProblemData::DD;
	double** H = ProblemData::H;
	double* C = ProblemData::C; // total manufacturing capacity
#pragma endregion

#pragma region preparation
	int Old60 = (T * 0.6);
	int T0 = MinT; //RecT: number of Recession periods	
	int** Costs = new int* [nP];
	for (int p = 0; p < nP; p++)
	{
		Costs[p] = new int[T]();
		for (int t = 0; t < T; t++)
		{
			if (t < T0)
			{
				Costs[p][t] = 10e5;
			}
			else
			{
				if (t < DD[p])
				{
					Costs[p][t] = -(t - DD[p]) - T;
				}
				else
				{
					int dd = std::max(0, t - DD[p]);
					Costs[p][t] = dd * W[p];
				}

			}
		}
	}

	int* remCap = new int[T]();
	for (int t = 0; t < T; t++)
	{
		if (t < T0)
		{
			remCap[t] = 0;
		}
		else
		{
			int sumCap = 0;
			for (int n = nP; n < N; n++)
			{
				sumCap += D[n][t];
			}
			remCap[t] = std::max(0.0, C[t] - std::round(sumCap * CapCoef));
		}
	}
#pragma endregion


#pragma region solve the multiple knapsack problem
	IloEnv env; IloModel Model(env);
	NumVar2D z(env, nP);
	for (int p = 0; p < nP; p++)
	{
		z[p] = IloNumVarArray(env, T, 0, 1, ILOBOOL);
	}

	IloExpr ex0(env);
	for (int p = 0; p < nP; p++)
	{
		for (int t = 0; t < T; t++)
		{
			ex0 += z[p][t] * Costs[p][t];
		}
	}

	Model.add(IloMinimize(env, ex0));

	for (int t = 0; t < T; t++)
	{
		IloExpr ex1(env);
		for (int p = 0; p < nP; p++)
		{
			ex1 += H[p][t] * z[p][t];
		}
		Model.add(ex1 <= remCap[t]);
		ex1.end();
	}
	for (int p = 0; p < nP; p++)
	{
		IloExpr ex2(env);
		for (int t = 0; t < T; t++)
		{
			ex2 += z[p][t];
		}
		Model.add(ex2 == 1); ex2.end();
	}

	IloCplex cplex(Model);
	cplex.setOut(env.getNullStream());
	cplex.solve();
#pragma endregion
	double MKS_obj = (cplex.getObjValue());
	cout << "MinT: " << MinT << " Coef: " << CapCoef << " MKS Heurisitc Obj = " << MKS_obj << endl;
	//double** zl = new double* [nP];
#pragma region get Z values
	for (int p = 0; p < nP; p++)
	{
		Zl[p] = new double[T]();
		for (int t = 0; t < T; t++)
		{
			Zl[p][t] = cplex.getValue(z[p][t]);
		}
	}
#pragma endregion
	Model.end();
	cplex.end();
	//return zl;
}


bool ENG_Leader_Feasible(double** Zl, double** Yl)
{
	/*
	fix the Z variables ans solve the problem.
	If it is feasible, get Y variables.
	If not feasible, indicate by returning false
	*/

#pragma region  Fetch Data
	int N = ProblemData::N;
	int T = ProblemData::T;

	int nP = ProblemData::nP;
	double** D = ProblemData::D;
	double* W = ProblemData::W;
	int* DD = ProblemData::DD;
	double** H = ProblemData::H;
	double* pi = ProblemData::pi;

	double b = ProblemData::b; // backorder cost
	double h = ProblemData::h; // holding cost
	double r = ProblemData::r; // production cost
	double* C = ProblemData::C; // total manufacturing capacity
	double tolerance = ProblemData::eps;
	//double BigM = 10e7;
#pragma endregion

#pragma region Define Original Variables
	IloEnv env;
	IloModel Model(env);

	IloNumVarArray V(env, nP, 0, IloInfinity, ILOFLOAT);
	NumVar2D B(env, N);
	NumVar2D X(env, N);
	NumVar2D Y(env, nP);
	//NumVar2D Z(env, nP);
	NumVar2D I(env, N);


	for (int n = 0; n < N; n++)
	{

		B[n] = IloNumVarArray(env, T, 0, IloInfinity, ILOFLOAT);
		X[n] = IloNumVarArray(env, T, 0, 1, ILOFLOAT);
		I[n] = IloNumVarArray(env, T, 0, IloInfinity, ILOFLOAT);
	}
	for (int p = 0; p < nP; p++)
	{
		//Z[p] = IloNumVarArray(env, T, 0, 1, ILOBOOL);
		Y[p] = IloNumVarArray(env, T, 0, 1, ILOBOOL);
	}
#pragma endregion

#pragma region Define Dual MFG Variables
	// MFG Dual variables (excluding alph and beta variables which are indexed by j)
	NumVar2D zeta(env, N);
	IloNumVarArray psi(env, T, -IloInfinity, 0, ILOFLOAT);
	NumVar2D theta(env, nP);
	for (int n = 0; n < N; n++)
	{
		zeta[n] = IloNumVarArray(env, T, -IloInfinity, IloInfinity, ILOFLOAT);
	}
	for (int p = 0; p < nP; p++)
	{
		theta[p] = IloNumVarArray(env, T, -IloInfinity, 0, ILOFLOAT);
	}
#pragma endregion


#pragma region Define the Objective Function
	IloExpr ex0(env);
	for (int p = 0; p < nP; p++)
	{
		ex0 += W[p] * V[p];
	}
	Model.add(IloMinimize(env, ex0));
	ex0.end();
#pragma endregion

#pragma region Y_t =1 ==> Y_a>t =1
	for (int p = 0; p < nP; p++)
	{
		for (int t = 0; t < T - 1; t++)
		{
			Model.add(Y[p][t] <= Y[p][t + 1]);
		}
	}
#pragma endregion

#pragma region leader and followers Constraints 
	//MFG 0 define the Y variable
	for (int p = 0; p < nP; p++)
	{
		for (int t = 0; t < T; t++)
		{
			IloExpr ex1(env);
			for (int t2 = 0; t2 <= t; t2++) { ex1 += Zl[p][t2]; }
			//Model.add(1000 * Y[p][t] >= ex0);
			Model.add(Y[p][t] <= ex1);
			ex1.end();

		}
	}

	// MFG 1
	for (int n = 0; n < N; n++)
	{
		for (int t = 0; t < T; t++)
		{
			if (t > 0)
			{
				Model.add(I[n][t] == I[n][t - 1] + C[t] * X[n][t] - (D[n][t] + B[n][t - 1] - B[n][t]));
			}
			else
			{
				Model.add(I[n][t] == C[t] * X[n][t] - (D[n][t] - B[n][t]));
			}
		}
	}

	// MFG 2
	for (int t = 0; t < T; t++)
	{
		IloExpr ex4(env);
		for (int n = 0; n < N; n++)
		{
			ex4 += X[n][t];
		}
		Model.add(ex4 <= 1);
		ex4.end();
	}

	// MFG 3
	for (int p = 0; p < nP; p++)
	{
		for (int t = 0; t < T; t++)
		{
			Model.add(X[p][t] <= Y[p][t]);

		}
	}


	// Eng1 
	for (int p = 0; p < nP; p++)
	{
		for (int t = 0; t < T; t++)
		{
			IloExpr ex1(env);
			for (int t2 = 0; t2 < t; t2++) { ex1 += Zl[p][t2]; }
			Model.add(V[p] >= t * (1 - ex1) - DD[p]); ex1.end();
		}
	}

	// Eng2
	for (int t = 0; t < T; t++)
	{
		IloExpr ex7(env);
		for (int p = 0; p < nP; p++)
		{
			ex7 += H[p][t] * Zl[p][t];
		}
		for (int n = 0; n < N; n++)
		{
			ex7 += C[t] * X[n][t];
		}
		Model.add(ex7 <= C[t]);
		ex7.end();
	}


	// Eng 3
	for (int p = 0; p < nP; p++)
	{
		IloExpr ex0(env);
		for (int t = 0; t < T; t++)
		{
			ex0 += Zl[p][t];
		}
		Model.add(ex0 <= 1);
		ex0.end();
	}
#pragma endregion

#pragma region MFG Duals constraint
	// Dual MFG model
	for (int n = 0; n < N; n++)
	{
		for (int t = 0; t < T; t++)
		{
			if (t == T - 1)
			{
				Model.add(zeta[n][t] <= h);
			}
			else
			{
				Model.add(zeta[n][t] - zeta[n][t + 1] <= h);
			}
		}
	}

	for (int p = 0; p < nP; p++)
	{
		for (int t = 0; t < T; t++)
		{
			Model.add(-C[t] * zeta[p][t] + psi[t] + theta[p][t] <= r * C[t]);
		}
	}
	for (int n = nP; n < N; n++)
	{
		for (int t = 0; t < T; t++)
		{
			Model.add(-C[t] * zeta[n][t] + psi[t] <= r * C[t]);
		}
	}

	for (int n = 0; n < N; n++)
	{
		for (int t = 0; t < T; t++)
		{
			if (t == T - 1)
			{
				Model.add(-zeta[n][t] <= b);
			}
			else
			{
				Model.add(-zeta[n][t] + zeta[n][t + 1] <= b);
			}
		}
	}
#pragma endregion

#pragma region Linearize the non-linear term in the MFG-Dual objective function
	NumVar2D tY(env, nP);
	for (int p = 0; p < nP; p++)
	{
		tY[p] = IloNumVarArray(env, T);
		for (int t = 0; t < T; t++)
		{
			string name = "tY[" + to_string(p) + "][" + to_string(t) + "]";
			const char* name2 = name.c_str();
			tY[p][t] = IloNumVar(env, -IloInfinity, 0, ILOFLOAT, name2);
		}
	}
	for (int p = 0; p < nP; p++)
	{
		for (int t = 0; t < T; t++)
		{
			Model.add(IloIfThen(env, Y[p][t] == 1, tY[p][t] == theta[p][t]));
			Model.add(IloIfThen(env, Y[p][t] == 0, tY[p][t] == 0));
		}
	}
#pragma endregion

#pragma region Strong duality 
	IloExpr ex_MFG(env);
	for (int n = 0; n < N; n++)
	{
		for (int t = 0; t < T; t++)
		{

			ex_MFG += h * I[n][t];
			ex_MFG += r * C[t] * X[n][t];
			ex_MFG += b * B[n][t];

		}
	}

	IloExpr ex_MFG_Dual(env);
	for (int n = 0; n < N; n++)
	{
		if (n < nP)
		{
			for (int t = 0; t < T; t++)
			{
				ex_MFG_Dual += tY[n][t];
			}

		}
		for (int t = 0; t < T; t++)
		{
			ex_MFG_Dual += -zeta[n][t] * D[n][t];
		}
	}
	for (int t = 0; t < T; t++)
	{
		ex_MFG_Dual += psi[t];
	}
	Model.add(IloAbs(-ex_MFG_Dual + ex_MFG) <= tolerance);
	ex_MFG.end();
	ex_MFG_Dual.end();
#pragma endregion

#pragma region Solve the model

	IloCplex cplex(Model);
	cplex.setParam(IloCplex::TiLim, 150);
	//cplex.setParam(IloCplex::EpGap, 0.6);
	//cplex.exportModel("MA_LP.lp");
	cplex.setOut(env.getNullStream());
	if (!cplex.solve()) {
		//env.error() << "Failed to optimize the Master Problem!!!" << endl;
		//system("pause"); 
		Model.end();
		cplex.end();
		return false;
	}
	double EENG_obj = cplex.getObjValue();
	//env.out() << "MP Solution status = " << cplex.getStatus() << endl;
	env.out() << "\n\n \t ENG-LB obj value = " << EENG_obj << endl;
#pragma endregion


	// get Y variables.
	//Yl = new double* [nP];
	for (int p = 0; p < nP; p++)
	{
		Yl[p] = new double[T]();
		for (int t = 0; t < T; t++)
		{
			Yl[p][t] = cplex.getValue(Y[p][t]);			
		}
	}
	Model.end();
	cplex.end();
	return true;;
}


bool ENG_Leader_WarmStart_ZY(double** Zl, double** Yl, double& LB, double& status)
{
	// return the LB for the original problem (CORP) objective
#pragma region  Fetch Data
	int N = ProblemData::N;
	int T = ProblemData::T;

	int nP = ProblemData::nP;
	double** D = ProblemData::D;
	double* W = ProblemData::W;
	int* DD = ProblemData::DD;
	double** H = ProblemData::H;
	double* pi = ProblemData::pi;

	double b = ProblemData::b; // backorder cost
	double h = ProblemData::h; // holding cost
	double r = ProblemData::r; // production cost
	double* C = ProblemData::C; // total manufacturing capacity
	double tolerance = ProblemData::eps;
	//double BigM = 10e7;
#pragma endregion

#pragma region Define Original Variables
	IloEnv env;
	IloModel Model(env);

	IloNumVarArray V(env, nP, 0, IloInfinity, ILOFLOAT);
	NumVar2D B(env, N);
	NumVar2D X(env, N);
	NumVar2D Z(env, nP);
	NumVar2D Y(env, nP);
	NumVar2D I(env, N);


	for (int n = 0; n < N; n++)
	{

		B[n] = IloNumVarArray(env, T, 0, IloInfinity, ILOFLOAT);
		X[n] = IloNumVarArray(env, T, 0, 1, ILOFLOAT);
		I[n] = IloNumVarArray(env, T, 0, IloInfinity, ILOFLOAT);
	}
	for (int p = 0; p < nP; p++)
	{
		Z[p] = IloNumVarArray(env, T, 0, 1, ILOBOOL);
		Y[p] = IloNumVarArray(env, T, 0, 1, ILOBOOL);
	}
#pragma endregion

#pragma region Define Dual MFG Variables
	// MFG Dual variables (excluding alph and beta variables which are indexed by j)
	NumVar2D zeta(env, N);
	IloNumVarArray psi(env, T, -IloInfinity, 0, ILOFLOAT);
	NumVar2D theta(env, nP);
	for (int n = 0; n < N; n++)
	{
		zeta[n] = IloNumVarArray(env, T, -IloInfinity, IloInfinity, ILOFLOAT);
	}
	for (int p = 0; p < nP; p++)
	{
		theta[p] = IloNumVarArray(env, T, -IloInfinity, 0, ILOFLOAT);
	}
#pragma endregion


#pragma region Define the Objective Function
	IloExpr ex0(env);
	for (int p = 0; p < nP; p++)
	{
		ex0 += W[p] * V[p];
	}
	Model.add(IloMinimize(env, ex0));
	ex0.end();
#pragma endregion

#pragma region Y_t =1 ==> Y_a>t =1
	for (int p = 0; p < nP; p++)
	{
		for (int t = 0; t < T - 1; t++)
		{
			Model.add(Y[p][t] <= Y[p][t + 1]);
		}
	}
#pragma endregion

#pragma region leader and followers Constraints 
	//MFG 0 define the Y variable
	for (int p = 0; p < nP; p++)
	{
		for (int t = 0; t < T; t++)
		{
			IloExpr ex0(env);
			for (int t2 = 0; t2 <= t; t2++)
			{
				ex0 += Z[p][t2];
			}
			//Model.add(1000 * Y[p][t] >= ex0);
			Model.add(Y[p][t] <= ex0); ex0.end();

		}
	}

	// MFG 1
	for (int n = 0; n < N; n++)
	{
		for (int t = 0; t < T; t++)
		{
			if (t > 0)
			{
				Model.add(I[n][t] == I[n][t - 1] + C[t] * X[n][t] - (D[n][t] + B[n][t - 1] - B[n][t]));
			}
			else
			{
				Model.add(I[n][t] == C[t] * X[n][t] - (D[n][t] - B[n][t]));
			}
		}
	}

	// MFG 2
	for (int t = 0; t < T; t++)
	{
		IloExpr ex4(env);
		for (int n = 0; n < N; n++)
		{
			ex4 += X[n][t];
		}
		Model.add(ex4 <= 1);
		ex4.end();
	}

	// MFG 3
	for (int p = 0; p < nP; p++)
	{
		for (int t = 0; t < T; t++)
		{
			Model.add(X[p][t] <= Y[p][t]);

		}
	}


	// Eng1 
	for (int p = 0; p < nP; p++)
	{
		for (int t = 0; t < T; t++)
		{
			IloExpr ex2(env);
			for (int t2 = 0; t2 < t; t2++)
			{
				ex2 += Z[p][t2];
			}
			Model.add(V[p] >= t * (1 - ex2) - DD[p]);
			ex2.end();
		}
	}

	// Eng2
	for (int t = 0; t < T; t++)
	{
		IloExpr ex7(env);
		for (int p = 0; p < nP; p++)
		{
			ex7 += H[p][t] * Z[p][t];
		}
		for (int n = 0; n < N; n++)
		{
			ex7 += C[t] * X[n][t];
		}
		Model.add(ex7 <= C[t]);
		ex7.end();
	}


	// Eng 3
	for (int p = 0; p < nP; p++)
	{
		IloExpr ex0(env);
		for (int t = 0; t < T; t++)
		{
			ex0 += Z[p][t];
		}
		Model.add(ex0 <= 1);
		ex0.end();
	}
#pragma endregion

#pragma region MFG Duals constraint
	// Dual MFG model
	for (int n = 0; n < N; n++)
	{
		for (int t = 0; t < T; t++)
		{
			if (t == T - 1)
			{
				Model.add(zeta[n][t] <= h);
			}
			else
			{
				Model.add(zeta[n][t] - zeta[n][t + 1] <= h);
			}
		}
	}

	for (int p = 0; p < nP; p++)
	{
		for (int t = 0; t < T; t++)
		{
			Model.add(-C[t] * zeta[p][t] + psi[t] + theta[p][t] <= r * C[t]);
		}
	}
	for (int n = nP; n < N; n++)
	{
		for (int t = 0; t < T; t++)
		{
			Model.add(-C[t] * zeta[n][t] + psi[t] <= r * C[t]);
		}
	}

	for (int n = 0; n < N; n++)
	{
		for (int t = 0; t < T; t++)
		{
			if (t == T - 1)
			{
				Model.add(-zeta[n][t] <= b);
			}
			else
			{
				Model.add(-zeta[n][t] + zeta[n][t + 1] <= b);
			}
		}
	}
#pragma endregion

#pragma region Linearize the non-linear term in the MFG-Dual objective function
	NumVar2D tY(env, nP);
	for (int p = 0; p < nP; p++)
	{
		tY[p] = IloNumVarArray(env, T);
		for (int t = 0; t < T; t++)
		{
			string name = "tY[" + to_string(p) + "][" + to_string(t) + "]";
			const char* name2 = name.c_str();
			tY[p][t] = IloNumVar(env, -IloInfinity, 0, ILOFLOAT, name2);
		}
	}
	for (int p = 0; p < nP; p++)
	{
		for (int t = 0; t < T; t++)
		{
			Model.add(IloIfThen(env, Y[p][t] == 1, tY[p][t] == theta[p][t]));
			Model.add(IloIfThen(env, Y[p][t] == 0, tY[p][t] == 0));
		}
	}
#pragma endregion

#pragma region Strong duality 
	IloExpr ex_MFG(env);
	for (int n = 0; n < N; n++)
	{
		for (int t = 0; t < T; t++)
		{

			ex_MFG += h * I[n][t];
			ex_MFG += r * C[t] * X[n][t];
			ex_MFG += b * B[n][t];

		}
	}

	IloExpr ex_MFG_Dual(env);
	for (int n = 0; n < N; n++)
	{
		if (n < nP)
		{
			for (int t = 0; t < T; t++)
			{
				ex_MFG_Dual += tY[n][t];
			}

		}
		for (int t = 0; t < T; t++)
		{
			ex_MFG_Dual += -zeta[n][t] * D[n][t];
		}
	}
	for (int t = 0; t < T; t++)
	{
		ex_MFG_Dual += psi[t];
	}

	//Model.add(ex_MFG <= ex_MFG_Dual);
	Model.add(IloAbs(-ex_MFG_Dual + ex_MFG) <= tolerance);
	ex_MFG.end();
	ex_MFG_Dual.end();
#pragma endregion

	IloCplex cplex(Model);

#pragma region Warm Start
	IloNumVarArray XvarWarm(env);
	IloNumArray XvalWarm(env);
	IloNumVarArray YvarWarm(env);
	IloNumArray YvalWarm(env);
	for (int p = 0; p < nP; p++)
	{
		for (int t = 0; t < T; t++)
		{
			Model.add(Z[p][t]);
			Model.add(Y[p][t]);
			XvarWarm.add(Z[p][t]);
			XvalWarm.add(Zl[p][t]);
			YvarWarm.add(Y[p][t]);
			YvalWarm.add(Yl[p][t]);
		}
	}

	cplex.addMIPStart(XvarWarm, XvalWarm);
	cplex.addMIPStart(YvarWarm, YvalWarm);
	XvarWarm.end(); XvalWarm.end(); YvarWarm.end(); YvalWarm.end();
#pragma endregion


#pragma region Solve the model
	cplex.setParam(IloCplex::TiLim, 300);
	//cplex.setParam(IloCplex::EpGap, 0.6);
	//cplex.exportModel("MA_LP.lp");
	cplex.setOut(env.getNullStream());
	cplex.solve();
	double FeasGap = cplex.getMIPRelativeGap();
	if (FeasGap>10e-2)
	{
		status= -2;
		return true;
	}
	double EENG_obj = cplex.getObjValue();
	env.out() << "\n\n \t EENG-LB obj value = " << EENG_obj << endl;
#pragma endregion

	for (int n = 0; n < nP; n++)
	{
		Zl[n] = new double[T]();
		Yl[n] = new double[T]();
		for (int t = 0; t < T; t++)
		{
			Zl[n][t] = cplex.getValue(Z[n][t]);
			Yl[n][t] = cplex.getValue(Y[n][t]);

		}
	}

#pragma region Get the varibles (X,B,Z)
	double** Bl = new double* [N];
	double** Xl = new double* [N];
	// get the value of X
	for (int n = 0; n < N; n++)
	{
		Bl[n] = new double[T]();
		Xl[n] = new double[T]();
		for (int t = 0; t < T; t++)
		{
			Xl[n][t] = cplex.getValue(X[n][t]);
			Bl[n][t] = cplex.getValue(B[n][t]);
		}
	}
#pragma endregion

#pragma region Check the obj with that of the ENG subproblem
	double** Zh = new double* [nP];
	for (int p = 0; p < nP; p++)
	{
		Zh[p] = new double[T]();
	}
	double* Vh = new double[nP];
	double ENGobj2 = ENGSubProblem(Xl, Zh, Vh);
	if (std::abs(EENG_obj - ENGobj2) > 1)
	{
		Model.end();
		cplex.end();
		return false;
	}
#pragma endregion


#pragma region Get the lower bound by pluggin in B variables
	LB = 0;
	for (int n = 0; n < N; n++)
	{
		for (int t = 0; t < T; t++)
		{
			if (t > 0)
			{
				LB += pi[n] * D[n][t];
				LB += pi[n] * Bl[n][t - 1];
				LB += -pi[n] * Bl[n][t];
			}
			else
			{
				LB += pi[n] * D[n][t];
				LB += -pi[n] * Bl[n][t];
			}
		}
	}

#pragma endregion
	Model.end();
	cplex.end();
	return true;
}


bool GetFeasibleSol(double& LB, double** Zl, double** Yl, double& status)
{

#pragma region  Fetch Data
	int N = ProblemData::N;
	int T = ProblemData::T;
	int nP = ProblemData::nP;
	int* DD = ProblemData::DD;
#pragma endregion

	int MinT = T;	
	/*for (int p = 0; p < nP; p++)
	{
		if (DD[p]<MinT)
		{
			MinT = DD[p];
		}
	}*/
	//MinT--;
	MinT = T - T * 0.6 + 1; // start with the first possible deadline period
	bool isSol = false;
	for (int i = MinT; i < T - 4; i++)
	{
		bool TerminateThisLoop = false;
		for (int c = 0; c < 3; c++)
		{
			double coef = 1 + c * 0.2;
			MKP_Heuristic(i, coef, Zl);
			 isSol = ENG_Leader_Feasible(Zl, Yl);
			if (isSol) { TerminateThisLoop = true; break; }
		}
		if (TerminateThisLoop) { break; }
	}

	if (!isSol){ return false; }	

	bool isOptimal = ENG_Leader_WarmStart_ZY(Zl, Yl, LB, status);

	return isOptimal;
}