
#include "ProblemData.h";
#include "Funcs.h";

/* Code summary
Statrt date: 06/11/2019   end date: 3/29/2020
This code used the method proposed in the following paper to solve the bilevel
program of the semiconductor problem:
Rahman Khorramfar, Osman Ozaltin ...
*/
/*
HOW TO SET UP CPLEX FOR C++  :
https://bzdww.com/article/134619/
https://www.youtube.com/watch?v=Hbn1pGWLeaA
1) go to IBM directory in the program files in driver C
2) Go to concert folder -> include and when you see the "ilconcert" folder, copy the directory somewhere
3) Goto cplex folder -> include and when you see the "ilcplex" folder, copy the directory somewhere
4) In the solution Explorer tab, click on the project name and select properties
5) Go to C/C++ general ->" additional include directories" -> paste the two directories:
C:\Program Files\IBM\ILOG\CPLEX_Studio129\concert\include
C:\Program Files\IBM\ILOG\CPLEX_Studio129\cplex\include

6) Go to C/C++ general ->"Preprocessors" and add these words:
WIN32
_CONSOLE
IL_STD
_CRT_SECURE_NO_WARNINGS


Or
NDEBUG
_CONSOLE
IL_STD


7)  In the Project1 property page, select: "c/c++" - "code generation" - "runtime library",
set to "multithreaded DLL (/MD)". determine.

8) In the Project1 property page, select: "Linker" - "Input" - "Additional Dependencies",
and then enter the path of the following three files:
C:\Program Files\IBM\ILOG\CPLEX_Studio129\cplex\lib\x64_windows_vs2017\stat_mda\cplex1290.lib
C:\Program Files\IBM\ILOG\CPLEX_Studio129\cplex\lib\x64_windows_vs2017\stat_mda\ilocplex.lib
C:\Program Files\IBM\ILOG\CPLEX_Studio129\concert\lib\x64_windows_vs2017\stat_mda\concert.lib


9) if you're using visual studio 2017 with cplex 12.8, you may encounter an error which you then may
follow this link: https://www-01.ibm.com/support/docview.wss?uid=ibm10718671

*/

using namespace std;
//double  MasterProblem(vector<Double2D> Z, double** Xs);
//double ENGSubProblem(double** Xh, double** Zh, double* Vh);

int main(int argc, char* argv[]) {
	RandGen RG;
	if (argc > 1)
	{
		ProblemData::T = atoi(argv[1]);
		ProblemData::N = atoi(argv[2]);
		ProblemData::nP = atoi(argv[3]);
		RG.seed = atoi(argv[4]);
	}
	else
	{
		ProblemData::T = 12;
		ProblemData::N =14;
		ProblemData::nP = 5;
		RG.seed = 164;//4,163,506,731,999,1203
	}
	ProblemData::eps = (double)ProblemData::T*10;
	//ProblemData::eps = 500.0;
	std::default_random_engine gen(RG.seed);
	RG.Gen = gen;
	ProblemData::RandomInstanceGenerator(RG);
#pragma region  Fetch Data
	int N = ProblemData::N;
	int T = ProblemData::T;

	int nP = ProblemData::nP;
	double** D = ProblemData::D;
	double* W = ProblemData::W;
	int* DD = ProblemData::DD;
	double** H = ProblemData::H;
	double* pi = ProblemData::pi;

	double b = ProblemData::b; // backorder cost
	double h = ProblemData::h; // holding cost
	double r = ProblemData::r; // production cost
	double* C = ProblemData::C; // total manufacturing capacity
	int Old60 = (T * 0.6);
#pragma endregion	

	for (int t = 0; t < T; t++)
	{
		cout << "\t" << C[t];
	}


#pragma region Problem Parameters and Initial Values
	auto start = chrono::high_resolution_clock::now();

	double LB = 0;
	double UB = 10e12;  // upper bound
	double epsilon = 10e-4; // tolerance
	vector<EngSol> ZV;

	double** Zl = new double* [nP];
	double** Yl = new double* [nP];
	double** Zs = new double* [nP];
	double* Vs = new double[nP]();
	double** Ys = new double* [nP];
	double** Xs = new double* [N];
	double gap = -INFINITY;
	double EF_time = 3600;
	int ite = 0;
#pragma endregion

	double status = 1;
	bool IsFeasible = GetFeasibleSol(LB, Zl, Yl, status);
	if (!IsFeasible)
	{		
		Print_on_File2(RG, ite, 0, UB, 0, 0, gap, Xs, Zl, Yl, IsFeasible, status);
		return 0;
	}
	//status = -2;

	while (true)
	{
		ite++; gap = INFINITY;
		double corp_obj = RMP_Solution_Engine(ZV, Xs, Zs, Ys, Zl, Yl, gap, EF_time, LB, status);
		double RMP_eng = RMP_ENG_Obj(Zs);


		double ENGobj = -INFINITY;
		double SP2Obj = INFINITY;
		UB = INFINITY;
		if (gap < 0.001)
		{
			UB = corp_obj;
			Vs = new double[nP]();
			ENGobj = ENGSubProblem(Xs, Zs, Vs);
			
			if (RMP_eng <= ENGobj)
			{
				SP2Obj = RMP_eng;
			}
			else
			{
				SP2Obj = MFG_ENG_SP2(Xs);
			}
		}

		auto end = chrono::high_resolution_clock::now();
		auto Elapsed = chrono::duration_cast<chrono::milliseconds>(end - start);
		double duration = Elapsed.count();
		std::cout << "\n\n Iteration " << ite << "\t MP Obj: " << UB << "\t SP1 Obj: "
			<< ENGobj << "\t SP2 Obj: " << SP2Obj << endl;
		std::cout << "Time" << Elapsed.count() << endl;;
		std::cout << endl;

		if ((abs(SP2Obj - ENGobj) <= epsilon) || duration > 7.2e6 || std::abs(UB) == INFINITY)
		{
			// print the output
			Print_on_File2(RG, ite, duration, UB, ENGobj, SP2Obj, gap, Xs, Zs, Ys, true, status);
			break;
		}
		else
		{
			//EngSol *newZV =  new EngSol(Zh, Vh);
			double** Znew = new double* [nP];
			double* Vnew = new double[nP];
			for (int p = 0; p < nP; p++)
			{
				Znew[p] = new double[T]();
				Vnew[p] = Vs[p];
				for (int t = 0; t < T; t++)
				{
					Znew[p][t] = Zs[p][t];
				}
			}
			EngSol newZV(Znew, Vnew);
			ZV.push_back(newZV);
			//ZV.push_back(EngSol());
			//ZV[ZV.size() - 1].Z = Zh;
			//ZV[ZV.size() - 1].V = Vh;
			//delete newZV;
		}

	}





}