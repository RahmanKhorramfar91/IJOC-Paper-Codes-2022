#include <ilcplex/ilocplex.h>;
#include "ProblemData.h";
using namespace std;

typedef IloArray<IloNumVarArray> NumVar2D; // to define 2-D decision variables
typedef IloArray<NumVar2D> NumVar3D;  // to define 3-D decision variables
typedef IloArray<NumVar3D> NumVar4D;  // to define 4-D decision variables

double ENGSubProblem(double** Xh, double** Zh, double* Vh)
{


#pragma region  Fetch Data
	int N = ProblemData::N;
	int T = ProblemData::T;

	int nP = ProblemData::nP;
	double** D = ProblemData::D;
	double* W = ProblemData::W;
	int* DD = ProblemData::DD;
	double** H = ProblemData::H;
	double* pi = ProblemData::pi;

	double b = ProblemData::b; // backorder cost
	double h = ProblemData::h; // holding cost
	double r = ProblemData::r; // production cost
	double* C = ProblemData::C; // total manufacturing capacity
#pragma endregion

#pragma region Define Variables
	IloEnv env;
	IloModel Model(env);

	NumVar2D Z(env, nP);
	IloNumVarArray V(env, nP, 0, IloInfinity, ILOFLOAT);

	for (int p = 0; p < nP; p++) { Z[p] = IloNumVarArray(env, T, 0, 1, ILOBOOL); }
#pragma endregion

#pragma region Define the Objective Function
	IloExpr ex0(env);
	for (int p = 0; p < nP; p++) { ex0 += W[p] * V[p]; }

	Model.add(IloMinimize(env, ex0));
	ex0.end();
#pragma endregion

#pragma region constraints
	//Eng1: get the tardiness
	for (int p = 0; p < nP; p++)
	{
		for (int t = 0; t < T; t++)
		{
			IloExpr ex2(env);
			for (int t2 = 0; t2 < t; t2++)
			{
				ex2 += Z[p][t2];
			}
			Model.add(V[p] >= t * (1 - ex2) - DD[p]);
			ex2.end();
		}
	}

	//Eng2: Factory Capacity
	for (int t = 0; t < T; t++)
	{
		IloExpr ex1(env);
		for (int p = 0; p < nP; p++)
		{
			ex1 += H[p][t] * Z[p][t];
		}
		double rhs = C[t];
		for (int n = 0; n < N; n++)
		{
			rhs -= C[t] * Xh[n][t];
		}
		rhs = std::max(0.0, rhs);
		Model.add(ex1 <= rhs);
		ex1.end();
	}

	// Eng3: products developed at most once
	for (int p = 0; p < nP; p++)
	{
		IloExpr ex0(env);
		for (int t = 0; t < T; t++)
		{
			ex0 += Z[p][t];
		}
		Model.add(ex0 <= 1);
		ex0.end();
	}
#pragma endregion

#pragma region Solve and get the solution
	IloCplex cplex(Model);
	//cplex.exportModel("EngModel.lp");
	cplex.setOut(env.getNullStream()); // turn off cplex's logging to console
	if (!cplex.solve()) {
		env.error() << "Failed to optimize ENG subproblem " << endl;
		throw(-1);
	}
	//cout << "ENG status:" << cplex.getStatus() << endl;
	cout << "\t Eng Model Objective Value: " << cplex.getObjValue() << endl;
	//Zh = new double* [nP]; // make sure that Zh and Vh start empty
	//Vh = new double[nP]();
	for (int p = 0; p < nP; p++)
	{
		Zh[p] = new double[T]();
		for (int t = 0; t < T; t++)
		{
			//Zh[p][t] =cplex.getValue(Z[p][t]);			
			Zh[p][t] = std::max((double)0, std::round(cplex.getValue(Z[p][t])));
		}
		Vh[p] = std::max((double)0, std::round(cplex.getValue(V[p])));
		//Vh[p] = cplex.getValue(V[p]);
	}
#pragma endregion

#pragma region Print Solution
	//for (int p = 0; p < nP; p++)
	//{
	//	for (int t = 0; t < T; t++)
	//	{
	//		if (Zh[p][t] != 0)
	//		{
	//			//				cout << "\t Z[" << p << "][" << t << "] = " << cplex.getValue(Z[p][t]) << endl;
	//			cout << "\t Z[" << p << "][" << t << "] = " << Zh[p][t] << endl;
	//		}
	//	}
	//}

	//for (int p = 0; p < nP; p++)
	//{
	//	cout << "\t V[" << p << "] = " << cplex.getValue(V[p]) << endl;
	//}
#pragma endregion
	double obj = cplex.getObjValue();
	Model.end();
	cplex.end();
	return	obj;
}
















